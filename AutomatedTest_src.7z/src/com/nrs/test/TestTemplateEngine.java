package com.nrs.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dst.automatedtest.constant.Constant;
import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.log4j.CSHtmlLayout;
import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.ExcelTemplateReader;
import com.dst.automatedtest.reader.IReader;
import com.dst.automatedtest.reader.ParameterBean;
import com.dst.automatedtest.reader.PropertyReader;
import com.dst.automatedtest.report.BackupReport;
import com.dst.automatedtest.report.IReport;
import com.dst.automatedtest.report.WriteExcelFileResult;
import com.dst.automatedtest.util.FileUtil;

public class TestTemplateEngine {	
	
	private static Logger logger = null;
	private static boolean result = false;
	public static int testCaseSize;
	static {
		new BackupReport();
		BackupReport.backupDirectory();
		logger = LogManager.getLogger();
	}
	
	public static void main(String[] args) {
		long startTime = Calendar.getInstance().getTimeInMillis();
		
		System.out.println("Starting Engine... ");
		
		validateArgs(args);
		WriteExcelFileResult.setCurrentDir();
		  
    	String excelPath = WriteExcelFileResult.getCurrentDir()+PropertyReader.TEST_EXCEL_RESULT_PATH_NM;
    	String propPath = WriteExcelFileResult.getCurrentDir()+PropertyReader.TEST_PROP_RESULT_PATH_NM;
    	
    	try {
			FileUtil.createTmpPropertiesFile(propPath);
			WriteExcelFileResult.createExcelFileResult(excelPath);
		} catch (IOException eio) {
			// TODO Auto-generated catch block
			eio.printStackTrace();
		}
    	
		try {
	    	PropertyReader.getAppPropertyConfig( excelPath);
			PropertyReader.getAppPropertyConfig( PropertyReader.AUTOMATE_CONFIG_PATH );
			PropertyReader.getAppPropertyConfig( PropertyReader.AUTOMATE_VARIABLE_PATH );
			PropertyReader.getAppPropertyConfigTestSuit( PropertyReader.AUTOMATE_TESTSUIT_PATH );
			
			IReader reader = selectReader( PropertyReader.READERTYPE );
	        
	        AutomatedTestEngine engine = new AutomatedTestEngine( PropertyReader.TESTURL , reader , PropertyReader.BROWSER);
	        engine.setRemoteServer( PropertyReader.REMOTE );
	        
	        List<ParameterBean> testSuitList = null;
	        List<ParameterBean> testFailList = new ArrayList<ParameterBean>();
	        ArrayList<String> script = PropertyReader.TESTCASE_LISTS;
	        
	        testCaseSize = script.size();
	        IReport.setTOTAL_TESTCASE(testCaseSize);
	        
	        if(testCaseSize > 0){
		        for(int i =0; i < testCaseSize; i++){ 
		        	testSuitList = ((ExcelTemplateReader) reader).generateTest(script.get(i));
		        	List<ParameterBean> resultList = run(testSuitList, false, reader, engine);
		        	
		        	if(resultList != null){
		        		testFailList.addAll(resultList);
		        	}
		        }
		        
		        int retestPropertyValue = Integer.parseInt(PropertyReader.RETEST);
				// setup for re-test failed case
				if(retestPropertyValue > 0){
					for (int retest = 0; retest < retestPropertyValue ; retest++) {
						if( testFailList.size() == 0 ){
							break;
						}
						
						logger.log(Level.INFO, Constant.RETEST , "Running failed test case again...");
						
						CSHtmlLayout.resetTESTCASE_COUNT();
						testSuitList.clear();
						testSuitList.addAll(testFailList);
						testFailList.clear();
						
						List<ParameterBean> resultList = run(testSuitList, true, reader, engine);
						if(resultList != null){
			        		testFailList.addAll(resultList);
			        	}
					}
				}
	        }
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConnections();
		}
        PropertyReader.clearAllValue();
		System.out.println("Finishing Engine... ");		
		CSHtmlLayout.setFINISH(true);
		long endTime = Calendar.getInstance().getTimeInMillis();
		System.out.println("Total Time :: " + (endTime - startTime) + " ms");
		
	}
	
	private static List<ParameterBean> run(List<ParameterBean> testSuitList, boolean reTest, IReader reader, AutomatedTestEngine engine) throws Exception {
		ParameterBean testSuit = null;
		List<ElementBean> list = null;
		Map<String, Boolean> pointer = null;
		List<String> failedScript = new ArrayList<String>();
		List<ParameterBean> testFailList = null;
		
		for(int i = 0; i < testSuitList.size(); i++){
    		testSuit = testSuitList.get(i);
    		list = testSuit.getFunctionFlow();
    		
    		pointer = isContinuousTestCase(testSuitList, i);
    		
    		((ExcelTemplateReader) reader).storeParameterToProp(testSuit, pointer.get("isNotLast"));
    		
    		try {
    			if(reTest){
    				AutomatedTestEngine.fileName.push(((ExcelTemplateReader) reader).getFullCaseName(testSuit));
    			}
    			if(!failedScript.isEmpty() && testSuit.getCaseName().equalsIgnoreCase(failedScript.get(failedScript.size() - 1))){
    				AutomatedTestEngine.fileName.pop();
    				continue;
    			}
    			
    			//Change report file for new case.
    			if( !pointer.get("isNotLast")){
    				BackupReport.changeReportFileNm("TestCase" + AutomatedTestEngine.testCase);
    				BackupReport.reConfig();
    			}
    			
				result = engine.execute((ArrayList<ElementBean>) list, pointer.get("hasNext"));
			} catch (Exception e) {
				e.printStackTrace();
				result = false;
				pointer.put("hasNext", false);
			}
    		
    		if( result ){
    			logger.log( Constant.STATUS_COMPLETE , Constant.MAIN , ((ExcelTemplateReader) reader).getFullCaseName(testSuit) );
    			IReport.increaseSUCCESS_CASE();
    		}
    		else{
    			logger.log( Level.ERROR , Constant.MAIN , ((ExcelTemplateReader) reader).getFullCaseName(testSuit) );
    			
    			if(!failedScript.contains(testSuit.getCaseName())){
    				failedScript.add(testSuit.getCaseName());
    			}
    			
    			IReport.increaseFAILED_CASE();
    		}
    		
    		if(!pointer.get("hasNext")){
    			CSHtmlLayout.increaseRUNNING_TESTCASE();
    		}
    		
    		CSHtmlLayout.increaseTESTCASE_COUNT();
    		CSHtmlLayout.setCount(1);
    	}
		
		if( failedScript.size() > 0 ){
    		testFailList = getFailTestCase(failedScript, testSuitList);
    	}
		
		return testFailList;
	}
	
	private static List<ParameterBean> getFailTestCase(List<String> failedList, List<ParameterBean> previousTestList){
		List<ParameterBean> testFailList = new ArrayList<ParameterBean>();
		
		for(int i = 0, x = 0; x < failedList.size(); i++){
			ParameterBean testSuit = previousTestList.get(i);
			
			if(testSuit.getCaseName() == null || failedList.get(x).equals(testSuit.getCaseName())){
				testFailList.add(testSuit);
				
				String nextCase = (i+1 < previousTestList.size()) ? previousTestList.get(i+1).getCaseName() : "";
				
				Boolean hasNext = false;
				if(testSuit.getCaseName() == null){
        			hasNext = false;
        		}else{
        			hasNext = (testSuit.getCaseName().equalsIgnoreCase(nextCase)) ? true : false;
        		}
				
				if(!hasNext){
					x++;
				}
			}
		}
		
		return testFailList;
	}
	
	private static Map<String, Boolean> isContinuousTestCase(List<ParameterBean> testList, int currentPointer) {
		String currentCase = testList.get(currentPointer).getCaseName();
		String previousCase = (currentPointer > 0) ? testList.get(currentPointer - 1).getCaseName() : "";
    	String nextCase = (currentPointer + 1 < testList.size()) ? testList.get(currentPointer + 1).getCaseName() : "";
    	
    	Map<String, Boolean> pointer = new HashMap<String, Boolean>();
    	Boolean isNotLast = false;
    	Boolean hasNext = false;
    	
    	if(currentCase != null){
    		isNotLast = (currentCase.equalsIgnoreCase(previousCase)) ? true : false;
    		hasNext = (currentCase.equalsIgnoreCase(nextCase)) ? true : false;
    	}
    	
    	pointer.put("isNotLast", isNotLast);
    	pointer.put("hasNext", hasNext);
		
		return pointer;
	}
	
	private static void closeConnections() {
		for (Entry<String, Connection> entry : PropertyReader.TEST_CONN_MAP.entrySet()) {
			String key = entry.getKey();
			Connection conn = entry.getValue();
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Connection " + key + " has been closed.");
			}
		}
	}
	
	public static IReader selectReader(final String readerType){
		switch( readerType ){
			//case "text": return new TextFlowReader(); 
			case "excel": return new ExcelTemplateReader();
			default: return new ExcelTemplateReader();
		}
	}

	static void validateArgs(String[] argArr) {
		for (String myOpt : requiredParams) {
			boolean found = false;
			for (int i = 0; i < argArr.length; i++) {
				if (myOpt.equalsIgnoreCase(argArr[i])) {
					if (++i < argArr.length) {
						found = true;
						PropertyReader.setAppProperty(myOpt, argArr[i]);
					}
					break;
				}
			}
			
			if (!found) {
				System.out.println(" ERROR: Missing required parameters.    ");
				System.out.println(" Note:                                  ");
		        System.out.println(" -automate_config {automate_config} The name of the directory containing the settings file (automate_config.properties). ");
		        System.out.println(" -automate_variable {automate_variable} The name of the directory containing the settings file  (automate_variable.properties). ");
		        System.out.println(" -automate_testsuit {automate_testsuit} The name of the directory containing all test cases (automate_testsuit.properties). ");
				System.exit(4);
			}
		}
	}
	
	private static String[] requiredParams = {"-automate_config","-automate_variable","-automate_testsuit"};
}
