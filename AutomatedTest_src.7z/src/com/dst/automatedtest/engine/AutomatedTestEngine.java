package com.dst.automatedtest.engine;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.dst.automatedtest.constant.Constant;
import com.dst.automatedtest.driver.MyCustomRemoteWebDriver;
import com.dst.automatedtest.element.AlertElement;
import com.dst.automatedtest.element.CommandElement;
import com.dst.automatedtest.element.GetDataElement;
import com.dst.automatedtest.element.OpenElement;
import com.dst.automatedtest.element.ScriptElement;
import com.dst.automatedtest.element.SetVarElement;
import com.dst.automatedtest.element.SwitchWindowElement;
import com.dst.automatedtest.element.UpdateDataElement;
import com.dst.automatedtest.element.WaitElement;
import com.dst.automatedtest.element.WebElementImpl;
import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.IReader;
import com.dst.automatedtest.reader.PropertyReader;
import com.dst.automatedtest.report.BackupReport;
import com.dst.automatedtest.search.SearchIframe;
import com.dst.automatedtest.util.AssertionUtil;
import com.dst.automatedtest.util.CommandUtil;
import com.dst.automatedtest.util.WaitingCommandUtil;

public class AutomatedTestEngine {
	
	private static WebDriver driver = null;
	public static int Count = 0;
	public static int testCase = 1;
	public static int executeLine = 1;
	private Stack<Integer> tmpLine = new Stack<Integer>();
	private String URL ;
	private IReader reader ;
	private String Browser = Constant.IE ; 
	private String RemoteServer = null;
	public static Stack<String> fileName = new Stack<String>() ;
	private PropertyReader propertyReader = new PropertyReader("WebElements.properties");
	private PropertyReader propertyReaderMapping = new PropertyReader("MappingEventElements.properties");
	
	private PropertyReader waitReader = new PropertyReader("WaitConditions.properties");
	private Set<Object> waitPropKeys;
	
	private boolean isEnd = false;

	private static Logger logger = null;
	
	static {
		new BackupReport();
		logger = LogManager.getRootLogger();
	}
	
	public AutomatedTestEngine(String startURL) {
		this.URL = startURL;
		initDriver();
	}

	public AutomatedTestEngine(String startURL,IReader reader) {
		this.URL = startURL;
		this.reader = reader;
		initDriver();
	}
	
	public AutomatedTestEngine(String startURL,IReader reader,String browser) {
		this.URL = startURL;
		this.reader = reader;
		this.Browser = browser;
		initDriver();
	}
	
	private void initDriver() {

		File file = null;
		String webDriver = null;
		//String driverPath = new java.io.File("").getAbsoluteFile().getParentFile().getParentFile().getParentFile().getAbsolutePath();
		
		String driverPath = System.getenv().get("DRIVER");
//		System.out.println("---- "+driverPath);
		switch( Browser.toLowerCase() ){
		case "firefox" :
				/* Selenium is support firefox browser it needn't use driver */
				return;
		case "ie" : 
				file = new File(driverPath, "IEDriverServer.exe");
				webDriver = "webdriver.ie.driver";
				break;
		case "chrome" : 
				file = new File(driverPath, "chromedriver.exe");
				webDriver = "webdriver.chrome.driver";
				break;
		/*case "phantom" : 
				file = new File("driver_32/phantomjs.exe");
				webDriver = "webdriver.phantomjs.driver";
				break;*/
		default : 
				break;
		}
		System.setProperty( webDriver , file.getAbsolutePath() );
	}
	
	private void openBrowser(){
		try{
			if( RemoteServer.isEmpty() ){
				switch( Browser.toLowerCase() ){
				case "firefox" :
					FirefoxProfile firefoxProfile = new FirefoxProfile();
					firefoxProfile.setPreference("xpinstall.signatures.required", false);
					driver = new FirefoxDriver(firefoxProfile);
					break;
				case "chrome" :
					ChromeOptions options = new ChromeOptions();
					Map<String, Object> prefs = new HashMap<String, Object>();
					
					prefs.put("network.proxy.type", 2);
					prefs.put("network.proxy.autoconfig_url", "http://fxproxy.ns.dstcorp.net:8081/accelerated_pac_base.pac");
					options.setExperimentalOption("prefs", prefs);
					
					driver = new ChromeDriver(options);
					
					break;
				/*case "phantom" :
					Capabilities caps = new DesiredCapabilities();
					
					((DesiredCapabilities) caps).setJavascriptEnabled(true);                
					((DesiredCapabilities) caps).setCapability("takesScreenshot", true); 
					((DesiredCapabilities) caps).setCapability("web-security", "no");
					((DesiredCapabilities) caps).setCapability(
							PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
							System.getProperty("webdriver.phantomjs.driver"));
					
					driver = new PhantomJSDriver(caps);
					break;*/
				default : 
					driver = new InternetExplorerDriver();	
					break;
				}
			}
			else{
				DesiredCapabilities capabilities = null;
				
				switch( Browser.toLowerCase() ){
				case "firefox" :
					capabilities = DesiredCapabilities.firefox();
					break;
				case "chrome" :
					capabilities = DesiredCapabilities.chrome();
					break;
				default : 
					capabilities = DesiredCapabilities.internetExplorer();
					break;
				}

				capabilities.setJavascriptEnabled(true);
				
				System.out.println("Connecting to Selenium RC .... " );
				driver = new MyCustomRemoteWebDriver( new java.net.URL( RemoteServer ), capabilities );

			}
		
			driver.navigate().to( URL );
			driver.manage().window().maximize();
			
		}
		catch(Exception e){
			logger.error("Error Can't Create Driver for Testing...", e );
			System.out.println("Quit Driver");
			driver.close();
			System.exit(1);
		}
	}

	public boolean execute(ArrayList<ElementBean> elementList,boolean supCommand) throws Exception{
		boolean result = true;
		boolean breakCase = false;
		isEnd = false;

		long startTime = Calendar.getInstance().getTimeInMillis();
		
		System.out.println();
		
		logger.log( Constant.STATUS_START , "Execute TestCase "+testCase );
		logger.log( Constant.STATUS_START , AutomatedTestEngine.fileName.peek() );
	
		try {
		
			boolean hasQuit = true;
			if( driver != null )
				hasQuit = (driver.toString().contains("(null)")) ? true : false;
			if( hasQuit ){
				openBrowser();
			}
			
			this.waitPropKeys = waitReader.getAllPropertyKeys();
			
			for(Iterator<ElementBean> i = elementList.iterator(); i.hasNext(); ) {
				if (isEnd) {
					supCommand=false;
					break;
				}
				
				ElementBean anElement = i.next();
				executeLine=anElement.getLineNo();
				
				
				// Populate values for variables.
				anElement.setOriginalElementValue(anElement.getElementValue());
				anElement.setElementValue(PropertyReader.getAppVariableAndReplaceLine(anElement.getElementValue()));		
				anElement.setElementCondition(PropertyReader.getAppVariableAndReplaceLine(anElement.getElementCondition()));
				
				if(StringUtils.isNotBlank(anElement.getElementCondition())){
					String condition = anElement.getElementCondition();
					
					if(condition.contains("$")){
						continue;
					}
					
					ScriptEngineManager mgr = new ScriptEngineManager();
				    ScriptEngine scriptEngine = mgr.getEngineByName("JavaScript");
				    Boolean rslt = false;
				    try {
				    	
				    	Object obj = scriptEngine.eval(condition);
					    if (obj instanceof Boolean) {
					    	rslt = (Boolean) obj;
					    	//System.out.println("condition >> " + condition +" :: "+rslt);
						} else {
							throw new Exception( "Invalid condition" );
						}
				    	
					} catch (ScriptException se) {
						throw se;
					}
				    
				    if(!rslt){
				    	continue;
			    	}
				}
				
				//Thread.sleep( 1000 );
				
				switch( anElement.getElementType().toLowerCase() ){
				case "open":
					executeOpenElement( anElement , AutomatedTestEngine.fileName.peek() );
					break;
				case "command":
					executeCommandElement(anElement);	
					break;
				case "alert":
					executeAlertElement(anElement);		
					Thread.sleep( 1000 );
					break;
				case "popup":
					System.out.println("do nothing ...");
					//checkWindowPopUp( anElement.getMethod() );
					break;
				case "assert":
					executeAssert(anElement);
					break;
				case "selectq":
					executeCommandElementQueue(anElement);
					break;
				case "setvar":
					executeSetVarElement(anElement);
					break;
				case "getdata":
					executeGetDataElement(anElement);
					break;
				case "updatedata":
					executeUpdateDataElement(anElement);
					break;
				case "script":
					executeScript(anElement);
					break;
				case "wait":
					executeWait(anElement);
					break;
				case "assertvar":
					result = executeAssertVar(anElement);
					break;
				case "end":
					//supCommand=false;
					isEnd = true;
					break;
				case "switchwindow":
					executeSwitchWindowElement(anElement);		
					break;
				default:
					checkHTMLElement(anElement);
					break;
				}
				
				if( "link".equals(anElement.getElementType().toLowerCase())
						|| "button".equals(anElement.getElementType().toLowerCase())){
					Thread.sleep( 1000 );
				}
				
				// Exit if found an error.
				if (!result) { 
					break;
				}
				
				if (isEnd) {
					break;
				}
			}
			
			// Write logs for executing test cases completed. 
			if (result) {
				logger.log( Constant.STATUS_COMPLETE , "Execute TestCase " +AutomatedTestEngine.fileName.pop() );
				logger.log( Constant.STATUS_COMPLETE , "Completed" );
			}
		} catch (Exception ex) {
			result = false;
			
			try{
				CommandUtil.captureScreen( driver );
				logger.error( "Error can't execute Script from "+ fileName.pop() +" Line : "+executeLine , ex );
				logger.log( Constant.STATUS_IMAGE ,"<img src=\"./screens/screenshots_"+(AutomatedTestEngine.Count-1)+".jpg\">");
				//System.out.println( "Error can't execute Script from "+ fileName.pop() +" Line : "+executeLine );
				if( parentWindowHandler != null ){
					driver.close();
					driver.switchTo().window( parentWindowHandler );	
					logger.info("Quit Window Popup...");
				}
			}
			catch (Exception ex1) {
				logger.error( "Error Exception From WebDriver or Capture Screen",ex1 );
			}
			
			//Handler Occurrence from supCommand(Open Element).
			if( supCommand ){
				breakCase = true;
				
				System.out.println("Throw ex supCommand");
				throw ex;
			}
		} finally {
			// check line
			if( !supCommand ){
				closeEngine(startTime);
				executeLine = 1;				
			}
			else{
				if(!tmpLine.isEmpty()){
					executeLine= tmpLine.pop();
				}else{
					if(breakCase){
						closeEngine(startTime);
						breakCase = false;
					}
					executeLine = 1;
				}
			}
			
		}
		
		return result;
	}
	
	private void executeUpdateDataElement(ElementBean anElement) throws Exception {
		try {
			logger.info( "Execute UpdateDataElement "+ executeLine +" : " + anElement.getElementName() + " = " + anElement.getElementValue() );
			Class<?> c = Class.forName("com.dst.automatedtest.element.UpdateDataElement");
			UpdateDataElement updateDataElement = (UpdateDataElement) c.newInstance();
			updateDataElement.invokeMethod(anElement);
		} catch (Exception e) {
			logger.error( "Can't Execute Command Update Data Line : "+ executeLine , e );
			throw e;
		}
	}

	private void executeGetDataElement(ElementBean anElement) throws Exception {
		try {
			logger.info( "Execute GetDataElement "+ executeLine +" : " + anElement.getElementName() + " = " + anElement.getElementValue() );
			Class<?> c = Class.forName("com.dst.automatedtest.element.GetDataElement");
			GetDataElement getDataElement = (GetDataElement) c.newInstance();
			getDataElement.invokeMethod(anElement);
		} catch (Exception e) {
			logger.error( "Can't Execute Command Get Data Line : "+ executeLine , e );
			throw e;
		}
	}
	
	private void executeScript(ElementBean anElement) throws Exception {
		try {
			logger.info( "Execute Script "+ executeLine +" : " + anElement.getElementName() + " = " + anElement.getElementValue() );
			Class<?> c = Class.forName("com.dst.automatedtest.element.ScriptElement");
			ScriptElement scriptElement = (ScriptElement) c.newInstance();
			scriptElement.invokeMethod(anElement);
		} catch (Exception e) {
			logger.error( "Can't Execute Command Script Line : "+ executeLine , e );
			throw e;
		}
	}
	
	private void executeWait(ElementBean anElement) throws Exception {
		try {
			logger.info( "Execute Wait Line "+ executeLine +" : " + anElement.getElementName() + " = " + anElement.getElementValue() );
			Class<?> c = Class.forName("com.dst.automatedtest.element.WaitElement");
			WaitElement waitElement = (WaitElement) c.newInstance();
			waitElement.invokeMethod(anElement);
		} catch (Exception e) {
			logger.error( "Can't Execute Command Wait Line : "+ executeLine , e );
			throw e;
		}
	}

	private void executeSetVarElement(ElementBean anElement) throws Exception {
		try {
			logger.info( "Execute SetVarElement "+ executeLine +" : " + anElement.getElementName() + " = " + anElement.getElementValue() );
			
			if("getText".equals(anElement.getMethod())){
				WebElement element = CommandUtil.findElement(driver, anElement);
				Class<?> c = Class.forName("com.dst.automatedtest.element.SetVarElement");
				SetVarElement setVarElement = (SetVarElement) c.getConstructor(WebElement.class).newInstance(element);
				setVarElement.invokeMethod(anElement);
			}else{
				Class<?> c = Class.forName("com.dst.automatedtest.element.SetVarElement");
				SetVarElement setVarElement = (SetVarElement) c.newInstance();
				setVarElement.invokeMethod(anElement);
			}
		} catch (Exception e) {
			logger.error( "Can't Execute Command Set Variable Line : "+ executeLine , e );
			throw e;
		}
	}

	public void executeCommandElement(ElementBean anElement) throws Exception {
		
		try {
			//System.out.println( "Execute CommandElement "+ executeLine +" : "+anElement.getElementName() +" : "+anElement.getMethod() );
			logger.info( "Execute CommandElement "+ executeLine +" : "+ anElement.getMethod() );
			
			Class<?> c = Class.forName("com.dst.automatedtest.element.CommandElement");
			CommandElement commandElement = (CommandElement) c.getConstructor(WebDriver.class).newInstance(driver);
			commandElement.invokeMethod(anElement);
				
		} catch (Exception e) {
			//System.out.println( "Can't Execute Command Script Line : "+ executeLine );
			logger.error( "Can't Execute Command Script Line : "+ executeLine , e );
			throw e;
		} 		
		
	}
	
	public void executeOpenElement( ElementBean anElement,String currentFileName ) throws Exception {
		
		try {
			tmpLine.push(executeLine);
			executeLine = 1;
			System.out.println( "Execute OpenElement "+ executeLine +" : "+anElement.getElementName() +" : "+anElement.getMethod() );
			logger.info( "Execute OpenElement "+ executeLine +" : "+anElement.getElementValue()  );
			
			AutomatedTestEngine.fileName.push( anElement.getElementValue() );
			
			Class<?> c = Class.forName("com.dst.automatedtest.element.OpenElement");
			OpenElement openElement = (OpenElement) c.getConstructor(WebDriver.class,IReader.class,AutomatedTestEngine.class,String.class)
														.newInstance(driver,reader,this,currentFileName);
			openElement.invokeMethod(anElement);
				
		} catch (Exception e) {
			//System.out.println( "Can't Execute Open Script Line : "+ executeLine );
			logger.error( "Can't Execute Open Script Line : "+ executeLine , e );
			throw e;
		} 		
		
	}
	
	public void executeAlertElement(ElementBean anElement) throws Exception{
		
		try {
			WaitingCommandUtil.waitForAlertUntilPresent( driver );
			//System.out.println("Execute AlertElement "+ executeLine +" : "+anElement.getMethod() );
			logger.info( "Execute AlertElement "+ executeLine +" : "+anElement.getMethod() );
			
			Class<?> c = Class.forName("com.dst.automatedtest.element.AlertElement");
			AlertElement alertElement = (AlertElement) c.getConstructor(WebDriver.class).newInstance(driver);
			alertElement.invokeMethod(anElement);
			
		} catch (Exception e) {
			//System.out.println( "Can't Execute Alert Script Line : "+ executeLine );
			logger.error( "Can't Execute Alert Script Line : "+ executeLine , e );
			throw e;
		} 		
	}
	
	public void executeSwitchWindowElement(ElementBean anElement) throws Exception{
		
		try {
			logger.info( "Execute SwitchWindowElement "+ executeLine );
			
			Class<?> c = Class.forName("com.dst.automatedtest.element.SwitchWindowElement");
			SwitchWindowElement switchWindowElement = (SwitchWindowElement) c.getConstructor(WebDriver.class).newInstance(driver);
			switchWindowElement.invokeMethod(anElement);
			
		} catch (Exception e) {
			logger.error( "Can't Execute SwitchWindow Script Line : "+ executeLine , e );
			throw e;
		} 		
	}
	
	public void checkHTMLElement(ElementBean anElement) throws Exception{
		// HTML ELEMENT
		//WaitingCommandUtil.waitPresent( driver );
		
		// retry to find element 2 round,if not found return exception 
		for( int retry=0 ; retry<=2 ;retry++ ){
			try{
				//System.out.println("retry "+retry);
				
				for(Object i:waitPropKeys){
					String key = (String) i;
					
					WaitingCommandUtil.waitForAny(driver, key, waitReader.getPropertyValue(key));
				}
				
				WaitingCommandUtil.waitForDocumentPageReady( driver );
				WaitingCommandUtil.waitForElementEnabled(driver, anElement);
				executeHTML(anElement);
				lastExecuteFlag = false;
				break;
			}
			catch( NoSuchElementException ex ){
				lastExecuteFlag = false;
				Thread.sleep( 10000 );
				if( retry==2 ){
					logger.error(  "Element hasn't found" , ex );
					throw new Exception( "Element hasn't found" );
				}
			}
		}
	}
	
	private Stack<WebElement> iframeMain = new Stack<WebElement>();
	private Stack<WebElement> iframeArray = new Stack<WebElement>();
	private Stack< Stack<WebElement> > iframeAllList = new Stack< Stack<WebElement> >();
	private String urlPage = "";
	
	private List<List<Object>> breadthFirstList = null;
	
	private boolean lastExecuteFlag = false;
	
	@SuppressWarnings("unchecked")
	public void executeHTML(ElementBean anElement ) throws Exception{
		checkIframe();
		iframeAllList.clear();
		
		breadthFirstList = preSearchIframe(anElement);
		Runnable r = new SearchIframe(breadthFirstList, anElement);
		Thread asyncThread = new Thread(r);
		asyncThread.start();
		
		
		do{
			try{
				// WebElement element = CommandUtil.findElement( driver,anElement );
				// WaitingCommandUtil.waitForElementPresent( driver, anElement );
				//logger.info( "Waiting for execute HTML ELEMENT Line "+ executeLine );
				//CommandUtil.scanElement(driver, anElement);
				WebElement element = CommandUtil.findElement(driver, anElement);
				WaitingCommandUtil.waitForElementEnabled(driver, element);
				executeHTMLElements(anElement, element);
				iframeArray.clear();
				iframeMain.clear();
				break;

			}
			catch( NoSuchElementException | TimeoutException e ){
				if( lastExecuteFlag ){
					if(anElement.isIgnore()){
						System.out.println("Ignore -> "+ anElement.getElementName() );
						break;
					}
					throw new NoSuchElementException("Element hasn't found -> "+ anElement.getElementName() );
				}
				else if( iframeList.size() > 0 ){
					if(!asyncThread.isAlive()){
						//System.out.println("[IN]");
						WebElement foundIframe = ((SearchIframe) r).getValue();
						
						if(foundIframe != null){
							System.out.println(anElement.getElementName());
							System.out.println(foundIframe.hashCode());
							asyncThread.interrupt();
							asyncThread.join();
							
							iframeMain.push(driver.switchTo().activeElement());
							driver.switchTo().frame(foundIframe);
							continue;
						}
					}
					//System.out.println("Find again ...");
					
					iframeMain.push(driver.switchTo().activeElement());
					driver.switchTo().frame(iframeList.pop());
					iframeArray = (Stack<WebElement>) iframeList.clone();
					iframeAllList.add( (Stack<WebElement>) iframeArray.clone() );
					checkIframe();
					
					/*	
					driver.switchTo().defaultContent();
					driver.switchTo().window( mainIFrame );
					try{
						driver.switchTo().frame( iframeList.pop() );
					}catch(StaleElementReferenceException ex){
						checkIframe();
					}
					*/
					
				}
				else if( iframeMain.size() > 0 ){
					//switch out off from current iframe to parent iframe.
					iframeMain.pop();
					driver.switchTo().parentFrame();
					//iframeList = (Stack<WebElement>) iframeArray.clone();
					iframeList = (Stack<WebElement>) iframeAllList.pop().clone();
				}
				else{
					//System.out.println("Find last round ...");
					//System.out.println( "Driver to Default Content "+driver.getCurrentUrl() );
					try{
						driver.switchTo().parentFrame();
					}catch(Exception switchError){
						driver.switchTo().defaultContent();
					}
					//driver.switchTo().parentFrame();

					if( driver.getCurrentUrl().equalsIgnoreCase( urlPage ) ){
						lastExecuteFlag = true;
					}else{
						urlPage = driver.getCurrentUrl() ;
					}
				}
			}
		}while( true );
	}

	public void executeHTMLElements(ElementBean anElement,WebElement element) throws Exception {	
		//long startTime = Calendar.getInstance().getTimeInMillis();
		WebElementImpl webElement = null;
		try {
			//System.out.println("Execute HTMLElement Line "+executeLine+" : "+anElement.getElementName() +" : "+anElement.getMethod());
			logger.info( "Execute HTMLElement Line "+executeLine+" : "+anElement.getElementName() +" : "+anElement.getElementValue() );
			Class<?> c = Class.forName(propertyReader.getPropertyValue( anElement.getElementType() ));

			switch ( anElement.getElementType().toLowerCase() ) {
			case "checkbox":
				webElement = (WebElementImpl) c.getConstructor(WebElement.class,WebDriver.class).newInstance(element,driver);
				break;
			case "radiobutton":
				webElement = (WebElementImpl) c.getConstructor(WebElement.class,WebDriver.class).newInstance(element,driver);
				break;
			case "texteditor":
				webElement = (WebElementImpl) c.getConstructor(WebElement.class,WebDriver.class).newInstance(element,driver);
				break;
			case "drag":
				webElement = (WebElementImpl) c.getConstructor(WebElement.class,WebDriver.class).newInstance(element,driver);
				break;
			default:
				webElement = (WebElementImpl) c.getConstructor(WebElement.class).newInstance(element);
				break;
			}

			webElement.invokeMethod(anElement);
			
		} catch (Exception e) {
			if(anElement.isIgnore()){
				System.out.println("Ignore -> "+ anElement.getElementName() );
				logger.info( "Ignore -> "+ anElement.getElementName() );				
			}else{			
				//System.out.println( "Can't Execute HTML Script Line : "+ executeLine );
				logger.error( "Can't Execute HTML Script Line : "+ executeLine , e );
				throw e;
			}
		} 
		//long endTime = Calendar.getInstance().getTimeInMillis();
		//System.out.println("Execute HTMLElement Total :: " + (endTime - startTime) + " ms");
	}
	
	public void executeAssert(ElementBean anElement){
		String option = anElement.getMethod();
		switch ( option.toLowerCase() ) {
		case "":
			AssertionUtil.AssertThat( 
						CommandUtil.findElement(driver, anElement).getAttribute("value") , 
						anElement.getElementValue() );
			break;
		default:
			break;
		}
	}
	
	public boolean executeAssertVar(ElementBean anElement){
		String value = PropertyReader.VARIABLE_KEY.get(anElement.getElementName());
		
		logger.info( "Execute AssertVar "+ executeLine +" : " + value + " = " + anElement.getElementValue() + "?");
		
		boolean result = AssertionUtil.AssertThat(value, anElement.getElementValue());
		
		// Write logs if equal assertion failed.
		if (!result) {
			logger.error( "Error can't execute Script from "+ fileName.pop() +" Line : " + executeLine, 
					new Exception("Equal assertion failed. " + anElement.getElementName() + " (Is " + value + ") is not equal " + anElement.getElementValue()));
		}
		return result;
	}
	
	private String parentWindowHandler = null;
	private boolean popup = false;
	private boolean popupIsPresentAlready = false;
	
	public void checkWindowPopUp(String option) throws Exception{
		logger.info("Execute Popup Line "+executeLine);
		//Set<String> handles = null;
		try {
			popup = true;
			//long startTime = Calendar.getInstance().getTimeInMillis();
			if (popup) {
				if( !popupIsPresentAlready ){
					
					parentWindowHandler = driver.getWindowHandle();
					popupIsPresentAlready = WaitingCommandUtil.waitForPopupPresent(driver);
					CommandUtil.switchToPopup( driver );

				}
				else{
					if( option.toLowerCase().equals("close") ){
						processSwitchWindow();
					}
				}
				
			}
			//long endTime = Calendar.getInstance().getTimeInMillis();
			//System.out.println("Popup is present :: " + (endTime - startTime) + " ms");
		} catch (Exception e) {
			//System.out.println("	**switch to parentWindowHandler ");
			logger.error( "Can't Process in Popup" , e );
			//e.printStackTrace();
			processSwitchWindow();
		}
	}
	
	private void processSwitchWindow() throws Exception{
		CommandUtil.switchToMainWindow( driver, parentWindowHandler );
		parentWindowHandler = null;
		popup = false;
		popupIsPresentAlready = false;
	}
	
	private Stack<WebElement> iframeList = new Stack<WebElement>();
	private String mainIFrame = "";
	private Map<String, Stack<WebElement> > mapIframe = new HashMap<String, Stack<WebElement> >();
	private void checkIframe(){
		Stack<WebElement> tmpiframeList = new Stack<WebElement>();
		Stack<WebElement> newiframeList = new Stack<WebElement>();
		
		try{
			tmpiframeList.addAll( driver.findElements( By.tagName("iframe") ) );
		}catch(Exception ee){
			driver.switchTo().parentFrame();
			tmpiframeList.addAll( driver.findElements( By.tagName("iframe") ) );
		}

		if( iframeList.size() == 0  || iframeList.size() >= tmpiframeList.size() )
		{
			iframeList.clear();
			iframeList = tmpiframeList;
		}
		else if( iframeList.size() < tmpiframeList.size() )
		{
			int count = tmpiframeList.size();

			for(int i=0; i<count ; i++){
				if( i< iframeList.size() ){
					if (! tmpiframeList.get( i ).equals( iframeList.get(i) ) ){
						newiframeList.add( tmpiframeList.get( i ) );
					}
				}
				else{
					newiframeList.add( tmpiframeList.get( i ) );
				}
			}
			iframeList.clear();
			iframeList = newiframeList;
			
			//mainIFrame = driver.getWindowHandle();
			
			if( iframeList.size() > 0 ){
				mainIFrame = driver.getWindowHandle();
				System.out.println("String of driver "+mainIFrame);
			}
			
		}
		
		//System.out.println("iframeList.size() "+ iframeList.size() );
		//printList(iframeList);
		
	}
	
	
	public void printList( List<WebElement> list ){
		Iterator<WebElement> CrunchifyIterator = list.iterator();

		while (CrunchifyIterator.hasNext()) {
			System.out.println(CrunchifyIterator.next().getAttribute("src"));
		}
	}
	
	private void initialInstanceVariable(){
		mainIFrame = "";
		iframeList = new Stack<WebElement>();
		parentWindowHandler = null;
		popup = false;
		popupIsPresentAlready = false;
		lastExecuteFlag = false;
	}

	public String getRemoteServer() {
		return RemoteServer;
	}

	public void setRemoteServer(String remoteServer) {
		RemoteServer = remoteServer;
	}

	public static WebDriver getDriver() {
		return driver;
	}

	
	public void executeStoredElement(ElementBean anElement,String key,String value) throws Exception{
		
		try {
			
		
			
		} catch (Exception e) {
			//System.out.println( "Can't Execute Alert Script Line : "+ executeLine );
			logger.error( "Can't Execute Alert Script Line : "+ executeLine , e );
			throw e;
		} 		
	}

	public void executeCommandElementQueue(ElementBean anElement) throws Exception {
		
		try {
			//System.out.println( "Execute CommandElement "+ executeLine +" : "+anElement.getElementName() +" : "+anElement.getMethod() );
			logger.info( "Execute CommandElement "+ executeLine +" : "+ anElement.getMethod() );
			
			Class<?> c = Class.forName("com.dst.automatedtest.element.CommandElement");
			CommandElement commandElement = (CommandElement) c.getConstructor(WebDriver.class).newInstance(driver);
			commandElement.invokeMethod(anElement);
				
		} catch (Exception e) {
			//System.out.println( "Can't Execute Command Script Line : "+ executeLine );
			logger.error( "Can't Execute Command Script Line : "+ executeLine , e );
			throw e;
		} 		
		
	}
	
	private void closeEngine(long startTime) {
		try {
			testCase++ ;
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// Quit Selenium on IE Web Driver. 
		// when UnreachableBrowserException from SocketTimeoutException: Read timed out it will be thrown exception.
		try{
			driver.quit();
		}catch (Exception e) {
			logger.error( "Error WebDriver Exception ",e );
		}
		
		initialInstanceVariable();
		
		long endTime = Calendar.getInstance().getTimeInMillis();
    	logger.info( "Total Time to run :: " + ( (endTime - startTime)/1000 ) + " sec" );
    	logger.info( "Finish Time :: " + Calendar.getInstance().getTime() );
		logger.info( "Quit Automated Test Engine" );
	}
	
	private List<List<Object>> preSearchIframe(ElementBean anElement) {
		List<List<Object>> iframePages = new ArrayList<List<Object>>();
		
		//long startTime = Calendar.getInstance().getTimeInMillis();
		//System.out.println("[START] Fn: preSerachIframe");
		
		int i = 0;
		
		for(WebElement iframe:iframeList){
			if(breadthFirstList != null && breadthFirstList.size() > 0 && breadthFirstList.size() > i){
				if(breadthFirstList.get(i).get(0).equals(iframe)){
					iframePages.add(breadthFirstList.get(i));
					//System.out.println(breadthFirstList.get(i).get(0).hashCode());
					i++;
					continue;
				}
			}
			
			List<Object> test = new ArrayList<Object>();
			try{
				driver.switchTo().frame(iframe);
			}catch(Exception e){
				continue;
			}
			//System.out.println("[SWITCH] "+ iframe.hashCode());
			
			String page = driver.getPageSource();
			
			test.add(iframe);
			test.add(page);
			iframePages.add(test);
			
			try{
				driver.switchTo().parentFrame();
			}catch(Exception switchError){
				driver.switchTo().defaultContent();
			}
			//driver.switchTo().parentFrame();
		}
		
		//System.out.println("[END] Fn: preSerachIframe");
		long endTime = Calendar.getInstance().getTimeInMillis();
    	//System.out.println("[TIME] " + (endTime - startTime) + " ms");
    	
    	return iframePages;
	}
}
