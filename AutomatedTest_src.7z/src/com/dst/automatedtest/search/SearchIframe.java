package com.dst.automatedtest.search;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.dst.automatedtest.reader.ElementBean;


public class SearchIframe implements Runnable {
	private List<List<Object>> iframeList = null;
	private ElementBean target;
	private volatile WebElement result = null;

	public SearchIframe(List<List<Object>> list, ElementBean target) {
		this.iframeList = list;
		this.target = target;
	}

	public void run() {
		for(List<Object> iframe: iframeList){
			if(((String) iframe.get(1)).contains(target.getElementName())){
				result = (WebElement) iframe.get(0);
				break;
			}
		}
	}
	
	public WebElement getValue() {
        return this.result;
    }
}
