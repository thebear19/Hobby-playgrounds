package com.dst.automatedtest.reader;

import java.util.ArrayList;

public interface IReader {

	public ArrayList<ElementBean> getElementList(String fullPathName);
	
	public ArrayList<ElementBean> getElementList(String fullPathName, String sheetName);
	
}
