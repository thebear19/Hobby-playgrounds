package com.dst.automatedtest.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.util.FileUtil;
import com.dst.automatedtest.util.StringUtil;

public class ExcelTemplateReader extends ExcelFlowReader {
	
	private PropertyReader propertyReader;
	private String sheetName;
	private static final String OPENFILE_COMMAND = "file";
	private static final String IGNORE_TAG = "[[->x]]";
	private static final String SKIP_TAG = "[[->N]]";
	private String caseParameterName = null;
	
	{
		propertyReader = new PropertyReader("MappingEventElements.properties");
		sheetName="";
	}
	
	public List<ParameterBean> generateTest(String fullPathName) {
		List<ParameterBean> beanList = null;
		
		if(isTestStep(fullPathName)){
			ParameterBean bean = new ParameterBean();
			
			bean.setFunctionFlow(getElementList(fullPathName));
			bean.setCaseName(fullPathName);
			
			beanList = new ArrayList<ParameterBean>();
			beanList.add(bean);
			AutomatedTestEngine.fileName.push(fullPathName);
		}else{
			beanList = getParameterList(fullPathName);
		}
		return beanList;
	}
	
	public List<ParameterBean> getParameterList(String fullPathName) {
		List<Map<Integer, String>> parameterList = null;
		List<ParameterBean> parameterObjList = null;
		
		parameterList = parameterReader(fullPathName);
			
		System.out.println("[SYSTEMLOG]: Generating parameter objects.");
		parameterObjList = generateParameterObject(parameterList);
		
		return parameterObjList;
	}
	
	public List<ParameterBean> getParameterList(String fullPathName, String sheetName) {
		this.sheetName = sheetName;
		List<ParameterBean> list = this.getParameterList(fullPathName);
		//this.sheetName = "";
		return list;
	}
	
	private List<Map<Integer, String>> parameterReader(String fullPathName) {
		List<Map<Integer, String>> parameterList = new ArrayList<Map<Integer, String>>();
		FileInputStream fs = null;
		Workbook wb = null;
		Sheet sh = null;
		
		try {
			fs = new FileInputStream(fullPathName);
			wb = WorkbookFactory.create(fs);

			if (StringUtils.isNotBlank(sheetName)) {
				for (int i = 0; i < wb.getNumberOfSheets(); i++) {
					if (wb.getSheetAt(i).getSheetName().equals(sheetName)) {
						sh = wb.getSheetAt(i);
						break;
					}
				}
			} else {
				sh = wb.getSheetAt(0);
			}
				
			Iterator<Row> rowIterator = sh.iterator();
		        
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				Cell cell = null;
				
				Map<Integer, String> parameterRow = new HashMap<Integer, String>();
				boolean isFirstCell = true;
				
				while (cellIterator.hasNext()) {
					cell = cellIterator.next();
					
					int index = cell.getColumnIndex();
					String rowValue = convertInputToString(cell);
					rowValue = StringUtil.isEmpty(rowValue) ? "" : rowValue;
					
					//Skip a row that have a bold style.
					Font font = wb.getFontAt(cell.getCellStyle().getFontIndex());    		
					/*if(font.getBold()){
						if(isFirstCell && font.getItalic()){
							rowValue = rowValue + SKIP_TAG;
						} else{
							rowValue = rowValue + IGNORE_TAG;
						}
					}*/
					
					if(isFirstCell && font.getBold()){
						rowValue = rowValue + SKIP_TAG;
					}
					else if(font.getBold() || font.getItalic()){
						rowValue = rowValue + IGNORE_TAG;
					}
					
					parameterRow.put(index, rowValue);
					
					if(!StringUtil.isEmpty(rowValue)){
						isFirstCell = false;
					}
				}
				
				if(!parameterRow.isEmpty()){
					parameterList.add(parameterRow);
				}
			}
		}
		catch (IOException e ) {
			File file = new File(".");
			for(String fileNames : file.list()) System.out.println(fileNames);
			e.printStackTrace();
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} 
		finally {
			try{
				if (wb!=null){
					wb.close();
				}
				
				if(fs!=null){
					fs.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
		return parameterList;
	}

	private List<ParameterBean> generateParameterObject(List<Map<Integer, String>> list) {
		int generateStep = 0;
		int noTest = 1;
		boolean normalLine = false;
		
		List<ParameterBean> parameterList = new ArrayList<ParameterBean>();
		List<ParameterBean> flowList = new ArrayList<ParameterBean>();
		Map<Integer, String> parameterNameList = null;
		
		System.out.println("[SYSTEMLOG]: ______ Testcase List ______");
		
		lineLoop: for(ListIterator<Map<Integer, String>> i = list.listIterator(); i.hasNext(); ) {
			Map<Integer, String> rowParameter = i.next();
			
			for(int colItem = 0, colItemIdx = 0; colItem < rowParameter.size(); colItemIdx++){
				try {
				
					//Skip blank cell
					if(!rowParameter.containsKey(colItemIdx)){
						if(parameterNameList != null && colItemIdx > parameterNameList.size()){
							throw new IOException("[ERRORLOG]: Cannot find some parameters.");
						}else{
							continue;
						}
					}
					
					//Reset when found header pattern.
					if(generateStep > 0 && isOpenCommand(rowParameter.get(colItemIdx))){
						generateStep = 0;
						flowList = new ArrayList<ParameterBean>();
					}
					
					if(isSkipTag(rowParameter.get(colItemIdx))){
						break;
					}
					
					switch (generateStep) {
					case 0: //Generate all TestStep in current TestCase and set tmp list.
						if(isOpenCommand(rowParameter.get(colItemIdx))){
							ParameterBean parameter = new ParameterBean();
							
							String cellInput = rowParameter.get(colItemIdx);
							boolean isIgnore = isIgnoreTag(cellInput);
							
							String filePath = removeOpenCommand(removeIgnoreTag(cellInput));
							filePath = FileUtil.stringToFullPath(filePath);
							
							if(FileUtil.isExcel(filePath)){
								if(!isIgnore){
									parameter.setFunctionFlow(getElementList(filePath));
								}
								parameter.setStartIndex(colItemIdx);
								parameter.setIgnore(isIgnore);
								
								flowList.add(parameter);
							}
						}
						
						colItem++;
					break;
					case 1: //Search CaseName and set tmp list.
						defineCaseName(rowParameter);
						
						parameterNameList = rowParameter;
						
						colItem = rowParameter.size();
						
						break;
					default: //Generate complete bean.
						ParameterBean parameterFlow = null;
						int endPoint = -1;
						
						for(int j = 0; j < flowList.size(); j++){
							int minRange = flowList.get(j).getStartIndex();
							int maxRange = (j + 1 < flowList.size())
									? flowList.get(j + 1).getStartIndex()
									: parameterNameList.size() + minRange;
							
							if(colItemIdx >= minRange && colItemIdx < maxRange){
								parameterFlow = flowList.get(j);
								endPoint = maxRange;
								
								break;
							}
						}
						
						if(parameterNameList.size() < rowParameter.size()){
							System.out.println("[INFOLOG]: Parameter size = " + parameterNameList.size());
							System.out.println("[INFOLOG]: Value size = " + rowParameter.size());
							System.out.println("[INFOLOG]: Parameter details = " + parameterNameList);
							System.out.println("[INFOLOG]: Value details = " + rowParameter);
							
							throw new OutOfMemoryError("[ERRORLOG]: Parameter's values size exceeds.");
						}
						
						if(parameterFlow == null || parameterFlow.isIgnore()){
							colItem++;
							break;
						}
						
						String caseName = "TestCase #" + noTest;
								
						ParameterBean parameter = new ParameterBean(parameterFlow);
						parameter.setCaseName(caseName);
						
						Map<String, String> parameterTmp = new HashMap<String, String>();
						boolean isAllEmpty = true;
						
						for(int startPoint = parameter.getStartIndex(); startPoint < endPoint; startPoint++){
							colItem++;
							
							String parameterName = parameterNameList.get(startPoint);
							
							if(StringUtil.isEmpty(parameterName) || isIgnoreTag(parameterName)){
								continue;
							}
							
							parameterName = "$" + parameterName.replace(" ", "");
							
							
							String parameterVal = rowParameter.get(startPoint);
							
							if(StringUtil.isEmpty(parameterVal) || isIgnoreTag(parameterVal)){
								if(parameterVal == null){
									colItem--;
								}
								
								parameterVal = "";
							}else{
								isAllEmpty = false;
							}
							
							parameterTmp.put(parameterName, parameterVal);
						}
						
						colItemIdx = endPoint - 1;
						
						String subCaseName = parameterTmp.get(this.caseParameterName);
						
						if(!isAllEmpty && !StringUtil.isEmpty(subCaseName)){
							parameter.setSubCaseName(subCaseName);
							parameter.setParameters(parameterTmp);
							parameterList.add(parameter);
							AutomatedTestEngine.fileName.push(getFullCaseName(parameter));
							
							showDebugConsole(parameter, false);
							normalLine = true;
						}
					}
				
					if(colItem >= rowParameter.size()){
						if(flowList.size() > 0){
							generateStep++;
						}
						
						if(generateStep >= 2 && normalLine){
							noTest++;
							normalLine = false;
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
					parameterList.clear();
					break lineLoop;
				}
			}
		}
		
		Collections.reverse(AutomatedTestEngine.fileName);
		System.out.println("[SYSTEMLOG]: ___________________________");
		
		return parameterList;
	}
	
	private void defineCaseName(Map<Integer, String> rowParameterName){
		for(int i = 0; i < rowParameterName.size(); i++){
			if(rowParameterName.get(i) != null && rowParameterName.get(i).replace(" ", "").equalsIgnoreCase("casename")){
				this.caseParameterName = "$" + rowParameterName.get(i).replace(" ", "");
				break;
			}
		}
	}
	
	private boolean isTestStep(String fullPathName) {
		FileInputStream fs = null;
		Workbook wb = null;
		Sheet sh = null;
		boolean isTestStep = false;
		String rowValue = null;
		
		
		try {
			if (!FileUtil.isExcel(fullPathName)) {
				throw new IOException("[ERRORLOG]: File type must be either xls or xlsx.");
			}

			fs = new FileInputStream(fullPathName);
			wb = WorkbookFactory.create(fs);
			sh = wb.getSheetAt(0);
				
			Iterator<Row> rowIterator = sh.iterator();
		        
			if(rowIterator.hasNext()) { 
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				Cell cell = null;
				
				if(cellIterator.hasNext()) {
					cell = cellIterator.next();
					rowValue = convertInputToString(cell);
					
					if(!isOpenCommand(rowValue)){
						if(cellIterator.hasNext() && rowValue.equalsIgnoreCase("Type")){
							cell = cellIterator.next();
							rowValue = convertInputToString(cell);
							
							isTestStep = rowValue.equalsIgnoreCase("ID/NAME/CLASS/Title_Text/Xpath");
						}else{
							throw new Exception("[ERRORLOG]: Cannot detect pattern in this file, Please clarify it before run again.");
						}
					}
				}
			}
		}
		catch (Exception e ) {
			e.printStackTrace();
		}
		finally {
			try{
				if (wb!=null){
					wb.close();
				}
				
				if(fs!=null){
					fs.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
		return isTestStep;
	}
	
	public void storeParameterToProp(ParameterBean parameter, boolean isNotLast) throws IOException {
		FileInputStream in = null;
		FileOutputStream out = null;
		Properties props;
		
		try {
			in = new FileInputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
			props = new Properties();
			props.load(in);
			in.close();
			out = new FileOutputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		
			if(!isNotLast){
				props.clear();
				PropertyReader.VARIABLE_KEY.clear();
			}
			if(parameter.getParameters() == null){
				out.close();
				return ;
			}
		
			for(String parameterKey: parameter.getParameters().keySet()){
				String parameterValue = parameter.getParameters().get(parameterKey);
				parameterValue = (parameterValue == null) ? "" : parameterValue;
				
				PropertyReader.VARIABLE_KEY.put(parameterKey, parameterValue);
				props.setProperty(parameterKey, parameterValue);
			}
			
			if(!props.isEmpty() && props != null){
				props.store(out, null);
			}
		} catch (IOException e) {
			throw new IOException("[ERRORLOG]: Have problem with propperties file.");
		}
		finally {
			try{
				if (in != null){
					in.close();
				}
				
				if(out != null){
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	}
	
	public String getFullCaseName(ParameterBean parameter) {
		String fullName = null;
		
		if(StringUtil.isEmpty(parameter.getSubCaseName())){
			fullName = parameter.getCaseName();
		}else{
			fullName = parameter.getCaseName() + " (" + parameter.getSubCaseName() + ")";
		}
		
		return fullName;
	}
	
	private String removeOpenCommand(String input){
		return input.replaceAll("(?i)"+ OPENFILE_COMMAND +"([\\s]|)>([\\s]|)", "");
	}
	
	private boolean isOpenCommand(String input) {
		return input.toLowerCase().replace(" ", "").startsWith(OPENFILE_COMMAND + ">");
	}
	
	private String removeIgnoreTag(String input) {
		return input.replace(IGNORE_TAG, "");
	}
	
	private boolean isIgnoreTag(String input) {
		return input.endsWith(IGNORE_TAG);
	}
	
	private boolean isSkipTag(String input) {
		return input.endsWith(SKIP_TAG);
	}
	
	private void showDebugConsole(ParameterBean parameter, boolean isDebugMode) {
		System.out.println("[SYSTEMLOG]: " + parameter.getCaseName() + " (" + parameter.getSubCaseName() + ") " +
				"["+ parameter.getParameters().size() +" parameters]");
		
		if(isDebugMode){
			System.out.println(parameter.getParameters().toString());
		}
	}
}
