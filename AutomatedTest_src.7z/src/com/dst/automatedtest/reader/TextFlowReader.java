package com.dst.automatedtest.reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TextFlowReader implements IReader{
	
	public ArrayList<ElementBean> getElementList(String fullPathName) {
		ArrayList<ElementBean> list = new ArrayList<ElementBean>();
		BufferedReader br = null;
		
	    try {
	        ElementBean elementBean = null;
	        String[] values = null;
	        br = new BufferedReader(new FileReader(fullPathName));
	        String line = br.readLine();
	        
	        while (line != null) {
	        	values = line.split("\\|");
	        	
	        	elementBean = new ElementBean();
	        	elementBean.setElementType(values[0]);
	        	elementBean.setElementName(values[1]);
	    		elementBean.setElementValue(values[2]);
	    		elementBean.setMethod(values[3]);
	    		list.add(elementBean);
	            line = br.readLine();
	        }
	    } catch (IOException e) {
			e.printStackTrace();
		} finally {
	        try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    return list;
	}
	
	public ArrayList<ElementBean> getElementList(String fullPathName, String sheetName){
		return this.getElementList(fullPathName);
	}
}
