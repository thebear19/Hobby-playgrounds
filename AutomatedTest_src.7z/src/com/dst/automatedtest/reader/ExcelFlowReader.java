package com.dst.automatedtest.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.dst.automatedtest.constant.Constant;
import com.dst.automatedtest.util.StringUtil;

public class ExcelFlowReader implements IReader {
	
	private PropertyReader propertyReader;
	private String sheetName;
	
	{
		propertyReader = new PropertyReader("MappingEventElements.properties");
		sheetName="";
	}
	
	public ArrayList<ElementBean> getElementList(String fullPathName) {
		ArrayList<ElementBean> list = new ArrayList<ElementBean>();
		FileInputStream fs = null;
		Workbook wb = null;
		Sheet sh = null;
		
		try {
			ElementBean elementBean = null;
			fs = new FileInputStream(fullPathName);
			wb = WorkbookFactory.create(fs);
		        
			if(StringUtils.isNotBlank(sheetName)){
				for(int i=0;i<wb.getNumberOfSheets();i++){
					if(wb.getSheetAt(i).getSheetName().equals(sheetName)){
						sh = wb.getSheetAt(i);
						break;
					}
				}
			}
			if (sh == null){
				sh = wb.getSheetAt(0);
			}
				
			Iterator<Row> rowIterator = sh.iterator(); 
		        
			readLine: while (rowIterator.hasNext()) { 
				Row row = rowIterator.next();
		        	
				String typeOfElement = "";
				String nameOfElement = "";
				String valueOfElement = "";
				String methodOfElement = "";
				String conditionOfElement = "";
		        	
				// Skip first
				if(row.getRowNum()==0){
					continue;		        		
				}
		        	
				Iterator<Cell> cellIterator = row.cellIterator();
				Cell cell = null;
		        	
				while (cellIterator.hasNext()) {
					cell = cellIterator.next();
		        	
					switch (cell.getColumnIndex()) {
					case 0:
						Font font = wb.getFontAt(cell.getCellStyle().getFontIndex());
						typeOfElement = StringUtil.trimAtBeginAndEndofString( cell.getStringCellValue() );
						
						//Skip Bold or type empty
						if(font.getBold() || StringUtil.isEmpty(typeOfElement)){
							continue readLine;
						}
						break;
					case 1:
						nameOfElement = StringUtil.trimAtBeginAndEndofString( cell.getStringCellValue() );
						break;
					case 2:
						valueOfElement = convertInputToString(cell);
						break;
					case 3:
						methodOfElement = StringUtil.trimAtBeginAndEndofString( cell.getStringCellValue() );
						break;
					case 4:
						conditionOfElement = StringUtil.trimAtBeginAndEndofString( cell.getStringCellValue() );
						
						if(conditionOfElement.equalsIgnoreCase("n")){
							continue readLine;
						}
						break;
					}	
				}
						
				// TODO Add function to check excel empty line
				if( typeOfElement != null && typeOfElement.trim() != "" ){
						
					elementBean = new ElementBean();
					elementBean.setElementId( Integer.toString(row.getRowNum()) );
					elementBean.setElementType( typeOfElement );
			       	elementBean.setElementName( nameOfElement );
			    	elementBean.setElementValue( valueOfElement );
			    	elementBean.setElementCondition( conditionOfElement );
			    	elementBean.setLineNo(row.getRowNum() + 1);
				    	
			    	if(Constant.IGNORE.equalsIgnoreCase(methodOfElement)){
			    		elementBean.setIgnore(true);
			    		methodOfElement = null;
			    	}else{
			    		elementBean.setIgnore(false);
			    	}
			    
			    	if( StringUtil.isEmpty(methodOfElement) )
			    		elementBean.setMethod( mappingMethodWithType( typeOfElement ) );
			    	else{
			    		elementBean.setMethod( methodOfElement );
			    	}
			    	list.add(elementBean);
				}
			}
			
			wb.close();
			fs.close();
		}
		catch (IOException e ) {
			File file = new File(".");
			for(String fileNames : file.list()) System.out.println(fileNames);
			e.printStackTrace();
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		}
		finally {
			try{
				if (wb!=null){
					wb.close();
				}
				
				if(fs!=null){
					fs.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
		return list;
	}
	
	private String mappingMethodWithType(String type){
		return propertyReader.getPropertyValue(type);
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	
	public ArrayList<ElementBean> getElementList(String fullPathName, String sheetName) {
		this.sheetName = sheetName;
		ArrayList<ElementBean> list = this.getElementList(fullPathName);
		this.sheetName = "";
		return list;
	}
	
	protected String convertInputToString(Cell cell){
		String parameter = null;
		DecimalFormat formatter = new DecimalFormat("#.###");
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
		
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_NUMERIC:
			if(DateUtil.isCellDateFormatted(cell)){
				parameter = dateFormatter.format(cell.getDateCellValue());
			}else{
				parameter = formatter.format(cell.getNumericCellValue());
			}
			break;
		case Cell.CELL_TYPE_BOOLEAN:
			parameter = Boolean.toString(cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_FORMULA:
			switch(cell.getCachedFormulaResultType()) {
			case Cell.CELL_TYPE_STRING:
				parameter = cell.getStringCellValue();
				break;
			case Cell.CELL_TYPE_NUMERIC:
				if(DateUtil.isCellDateFormatted(cell)){
					parameter = dateFormatter.format(cell.getDateCellValue());
				}else{
					parameter = formatter.format(cell.getNumericCellValue());
				}
				break;
			}				
			break;
		default: //String
			parameter = cell.getStringCellValue();
			break;
		}	
		
		parameter = StringUtil.trimAtBeginAndEndofString(parameter);
		
		return parameter;
		
	}
}
