package com.dst.automatedtest.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ExternalPropertyReader {

	public static void writeProperty(String path, String propertyName, String propertyValue){
		Properties prop = new Properties();
		FileOutputStream output = null;
		
		try {
			File f = new File(path);
			if(f.exists()){
				prop.load(new FileInputStream(path));
			}		
			prop.setProperty(propertyName, propertyValue);
			
			output = new FileOutputStream(path);
			prop.store(output, null);


		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static String readProperty(String path, String propertyName){
		Properties prop = new Properties();
		InputStream input = null;
		String value = null;
		try {

			input = new FileInputStream(path);
			prop.load(input);
			value = prop.getProperty(propertyName);


		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return value;
	}
}
