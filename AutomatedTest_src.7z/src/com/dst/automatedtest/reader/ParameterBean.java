package com.dst.automatedtest.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParameterBean {
	private String caseName;
	private String subCaseName;
	private List<ElementBean> functionFlow = new ArrayList<ElementBean>();
	private Map<String, String> parameters = new HashMap<String, String>();
	private int startIndex;
	private boolean isIgnore;
	
	public ParameterBean(){}
	
	//Copy constructor
	public ParameterBean(ParameterBean src){
		this.caseName = src.caseName;
		this.subCaseName = src.subCaseName;
		this.startIndex = src.startIndex;
		this.isIgnore = src.isIgnore;
		
		for(ElementBean eleBean : src.getFunctionFlow()){
			this.functionFlow.add(new ElementBean(eleBean));
		}
		
		for (Map.Entry<String, String> parameter : src.getParameters().entrySet()){
			this.parameters.put(parameter.getKey(), parameter.getValue());
		}
	}

	public List<ElementBean> getFunctionFlow() {
		return functionFlow;
	}

	public void setFunctionFlow(List<ElementBean> functionFlow) {
		this.functionFlow = functionFlow;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	public String getCaseName() {
		return caseName;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}
	
	public String getSubCaseName() {
		return subCaseName;
	}

	public void setSubCaseName(String subCaseName) {
		this.subCaseName = subCaseName;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public boolean isIgnore() {
		return isIgnore;
	}

	public void setIgnore(boolean isIgnore) {
		this.isIgnore = isIgnore;
	}
}
