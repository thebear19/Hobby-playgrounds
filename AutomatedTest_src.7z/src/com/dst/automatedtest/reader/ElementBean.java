package com.dst.automatedtest.reader;

public class ElementBean {
	private String elementId;
	private String elementName;
	private String elementClass;
	private String elementXPath;
	private String elementValue;
	private String elementType;
	private String method;
	private String originalElementValue;
	private boolean isIgnore;
	private String elementCondition;
	private int lineNo;
	
	
	public ElementBean(){}
	
	//Copy constructor
	public ElementBean(ElementBean src){
		this.elementId = src.elementId;
		this.elementName = src.elementName;
		this.elementClass = src.elementClass;
		this.elementXPath = src.elementXPath;
		this.elementValue = src.elementValue;
		this.elementType = src.elementType;
		this.method = src.method;
		this.originalElementValue = src.originalElementValue;
		this.isIgnore = src.isIgnore;
		this.elementCondition = src.elementCondition;
		this.lineNo = src.lineNo;
	}
	
	public String getElementId() {
		return elementId;
	}
	
	public void setElementId(String elementId) {
		this.elementId = elementId;
	}
	
	public String getElementName() {
		return elementName;
	}
	
	public void setElementName(String elementName) {
		this.elementName = elementName;
	}
	
	public String getElementXPath() {
		return elementXPath;
	}
	
	public void setElementXPath(String elementXPath) {
		this.elementXPath = elementXPath;
	}
	
	public String getElementValue() {
		return elementValue;
	}
	
	public void setElementValue(String elementValue) {
		this.elementValue = elementValue;
	}
	
	public String getElementType() {
		return elementType;
	}
	
	public void setElementType(String elementType) {
		this.elementType = elementType;
	}
	
	public String getMethod() {
		return method;
	}
	
	public void setMethod(String method) {
		this.method = method;
	}
	
	public String getElementClass() {
		return elementClass;
	}
	
	public void setElementClass(String elementClass) {
		this.elementClass = elementClass;
	}

	public String getOriginalElementValue() {
		return originalElementValue;
	}

	public void setOriginalElementValue(String originalElementValue) {
		this.originalElementValue = originalElementValue;
	}

	public boolean isIgnore() {
		return isIgnore;
	}

	public void setIgnore(boolean isIgnore) {
		this.isIgnore = isIgnore;
	}

	public String getElementCondition() {
		return elementCondition;
	}

	public void setElementCondition(String elementCondition) {
		this.elementCondition = elementCondition;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}	
	
}
