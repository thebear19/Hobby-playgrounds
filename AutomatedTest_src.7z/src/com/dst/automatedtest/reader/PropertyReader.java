package com.dst.automatedtest.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import com.dst.automatedtest.util.StringUtil;

public class PropertyReader {
	
	static Properties prop =null;
    
    public static String BROWSER = null;
    public static String READERTYPE = null;
    public static String TESTURL = null;
    public static String AUTOMATE_CONFIG_PATH = null;
    public static String AUTOMATE_TESTSUIT_PATH = null;
    public static String AUTOMATE_VARIABLE_PATH = null;
    public static String REMOTE = null;
    public static String RETEST = null;
    public static String TEST_PROP_RESULT_PATH_NM = null;
    public static String TEST_EXCEL_RESULT_PATH_NM = null;
    
    public static String FUNCTION_PATH = null;
    
    public static final String BROWSER_KEY = "-browser";
    public static final String READERTYPE_KEY  = "-readerType";
    public static final String URL_KEY = "-testUrl";
    public static final String REMOTE_KEY = "-remote";
    public static final String RETEST_KEY = "-retest";
    public static final String TEST_CONN_KEY = "-db";
    
    public static final String FUNCTION_PATH_KEY = "-functionPath";
    
    public static final String TESTCASE_KEY  = "-caseList";
    
    public static final String AUTOMATE_CONFIG_KEY = "-automate_config";
    public static final String AUTOMATE_TESTSUIT_KEY = "-automate_testsuit";
    public static final String AUTOMATE_VARIABLE_KEY = "-automate_variable";
    
    public static Map<Integer, String> TESTCASE_MAP = new HashMap<Integer, String>();
    public static ArrayList<String> TESTCASE_LISTS = new ArrayList<String>();
    public static Map<String, String> VARIABLE_KEY = new TreeMap<String, String>(Collections.reverseOrder());
    public static Map<String, Connection> TEST_CONN_MAP = new HashMap<String, Connection>();
    
	static InputStream input = null;
	String propertyName = null;
	public static BufferedReader br = null;
	public static String ALLOWED_REGEX_FLG = "false";
	
	private static Map<String, Map<String, String>> dbConfigMap = new HashMap<String, Map<String, String>>();
	
	public PropertyReader() {

	}
	
	public PropertyReader(String propertyName) {
			this.propertyName = propertyName;
	}
	
	public String getPropertyValue(String propertyName) {
		
		String propertyValue = null;
		
		try {
			input = PropertyReader.class.getClassLoader().getResourceAsStream(this.propertyName);
			try{
				if(input==null){
					input = new FileInputStream(this.propertyName);
				}
			}
			catch(FileNotFoundException ex){
				System.out.println("FileNotFoundException : " + this.propertyName);
				return null;
			}
			
			if(input==null){
    	        System.out.println("Sorry, unable to find " + this.propertyName);
    		    return propertyValue;
    		}
			
			prop.load(input);
			propertyValue = prop.getProperty(propertyName);
		
		} catch (IOException ex) {
			System.out.println("System failed to load testTool properties.");
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return propertyValue;
	}
	
	 public static void setAppProperty( String key, String value ){    
		if (key != null) {
			if (key.contains(TEST_CONN_KEY)) {
				String[] keyArry = key.split("\\.");
				String name = keyArry[1];
				String type = keyArry[2];
 				if (!dbConfigMap.containsKey(name)) {
 					dbConfigMap.put(name, new HashMap<String, String>());
 				}
 				dbConfigMap.get(name).put(type, value);
			} else {
				switch (key) {
				case AUTOMATE_CONFIG_KEY:
					AUTOMATE_CONFIG_PATH = value;
					break;
				case AUTOMATE_TESTSUIT_KEY:
					AUTOMATE_TESTSUIT_PATH = value;
					break;
				case AUTOMATE_VARIABLE_KEY:
					AUTOMATE_VARIABLE_PATH = value;
					break;
				case READERTYPE_KEY:
					READERTYPE = value;
					break;
				case URL_KEY:
					TESTURL = value;
					break;
				case BROWSER_KEY:
					BROWSER = value;
					break;
				case REMOTE_KEY:
					REMOTE = value;
					break;
				case RETEST_KEY:
					RETEST = value;
					break;
				case FUNCTION_PATH_KEY:
					FUNCTION_PATH = validateAndCleanFunctionPath(value);
					break;
				}
			}
		}
	}
	 
	public static void setAppPropertyMap(Integer key, String value) {
		if (!TESTCASE_MAP.containsKey(key)) {
			TESTCASE_MAP.put(key,value);
		}
	}
	
	public static void setAppVariableKey(String key, String value) {
		if (!VARIABLE_KEY.containsKey(key)) {
			VARIABLE_KEY.put(key, value);
		}
	}
	
	public static void getAppPropertyConfig(String configPath) {
		File tmpFile = new File( StringUtil.convertBackSlash( configPath.trim() ) );
		System.out.println("configpath."+configPath);
		if (!tmpFile.exists()) {
			System.out.println("ERROR: wrong path. "+configPath);
			System.exit(4);
		}
		try {
			StringReader reader = new StringReader( convertBackSlashinFile(tmpFile) );
			prop = new Properties();
			prop.load(reader);
			if (br != null) {
				Enumeration<Object> enuKeys = prop.keys();
				while (enuKeys.hasMoreElements()) {
					String key = (String) enuKeys.nextElement();
					String value = prop.getProperty(key);
					if(configPath.equalsIgnoreCase(AUTOMATE_CONFIG_PATH)){
					    setAppProperty(key, value);
				    }
					if(configPath.equalsIgnoreCase(AUTOMATE_VARIABLE_PATH)){
						setAppVariableKey( key, value); 
					}
				}
			}
			if(configPath.equalsIgnoreCase(AUTOMATE_CONFIG_PATH)){
				createConnByConfig();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void createConnByConfig() {
		for (Entry<String, Map<String, String>> entry : dbConfigMap.entrySet()) {
			String key = entry.getKey();
			Map<String, String> value = entry.getValue();
			String url = value.get("url");
			String user = value.get("user");
			String password = value.get("password");
			Connection conn = null;
			if (!StringUtil.isEmpty(url) && !StringUtil.isEmpty(user) && !StringUtil.isEmpty(password)) {
				try {
					Class.forName("oracle.jdbc.OracleDriver");
					conn = DriverManager.getConnection(url, user, password);
					conn.setAutoCommit(false);
					TEST_CONN_MAP.put(key, conn);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Connect to " + key + " database.");
			} else {
				System.out.println("ERROR: Missing some config to connect " + key + " database.");
			}
		}
	}

	public static void getAppPropertyConfigTestSuit(String configPath) {
		File tmpFile = new File( StringUtil.convertBackSlash( configPath.trim() ) );
		System.out.println("configpath."+configPath);
		if (!tmpFile.exists()) {
			System.out.println("ERROR: wrong path. "+configPath);
			System.exit(4);
		}
		try {
			StringReader reader = new StringReader( convertBackSlashinFile(tmpFile) );
			prop = new Properties();
			prop.load(reader);
			if (br != null) {
				Enumeration<Object> enuKeys = prop.keys();
				while (enuKeys.hasMoreElements()) {
					String key = (String) enuKeys.nextElement();
					String value = prop.getProperty(key);
					if(configPath.equalsIgnoreCase(AUTOMATE_TESTSUIT_PATH)){
						if (key.contains(TESTCASE_KEY)) {
							String str = key.replaceAll("[^0-9]", "");
							setAppPropertyMap(Integer.parseInt(str), value);
						}
					}
				}
			}
			if(!TESTCASE_MAP.isEmpty()){
			  Map<Integer, String> treeMap = new TreeMap<Integer, String>(TESTCASE_MAP);
			  Set<?> s = treeMap.entrySet();
			  Iterator<?> it = s.iterator();
			    while ( it.hasNext() ) {
			       Map.Entry entry = (Map.Entry) it.next();
			       int key = (int) entry.getKey();
			       String value = (String) entry.getValue();
			       System.out.println(key + " => " + value);	
			       TESTCASE_LISTS.add(value);
			    }
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 
	private static String convertBackSlashinFile(File file) {
		StringBuffer tmp = new StringBuffer();
		String line;
		try {
			br = new BufferedReader(new FileReader(file));
			while ((line = br.readLine()) != null) {
				tmp.append(StringUtil.convertBackSlash(line) + "\n");
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tmp.toString();
	}
	
	private static String validateAndCleanFunctionPath(String path){
		if (Files.isDirectory(Paths.get(path))) {
			if(path.charAt(path.length() - 1) == '\\'){
				path = path.substring(0, path.length() - 1);
			}
		}else{
			try {
				throw new FileNotFoundException();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		return path;	
	}
	 
	public static String getAppVariableAndReplaceLine(String sCurrentLine) {
		if (!StringUtil.isEmpty(sCurrentLine)) {
			for (Entry<String, String> entry : VARIABLE_KEY.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (sCurrentLine.contains(key)) {
//					System.out.println(" Variable key    : " + key);
//					System.out.println(" Variable value  : " + value);
//					System.out.println(sCurrentLine + " replace with " + value);
					
					if(VARIABLE_KEY.containsKey(value)){
						value = getAppVariableAndReplaceLine(value);
					}
					
					sCurrentLine = sCurrentLine.replaceAll(StringUtil.escapeSpecialRegexChars(key), StringUtil.convertBackSlash(value));
				}
			}
		}
		return sCurrentLine;
	}
	
	public Set<Object> getAllPropertyKeys() throws IOException {
		Set<Object> properties = new HashSet<Object>();
		
		InputStream in = PropertyReader.class.getClassLoader().getResourceAsStream(this.propertyName);
		try {
			if(in==null){
				in = new FileInputStream(this.propertyName);
			}
			Properties prop = new Properties();
			prop.load(in);
			in.close();
			
			properties = prop.keySet();
		} catch (IOException e) {
			throw new IOException("[ERRORLOG]: Have problem with propperties file.");
		}
		finally {
			try{
				if (in != null){
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
		
		return properties;
	}
	
	public static void clearAllValue() {
		BROWSER = null;
		READERTYPE = null;
		TESTURL = null;
		AUTOMATE_CONFIG_PATH = null;
		AUTOMATE_TESTSUIT_PATH = null;
		AUTOMATE_VARIABLE_PATH = null;
		REMOTE = null;
		RETEST = null;
		TESTCASE_MAP = null;
		TESTCASE_LISTS = null;
		VARIABLE_KEY = null;
		FUNCTION_PATH = null;
	}
}