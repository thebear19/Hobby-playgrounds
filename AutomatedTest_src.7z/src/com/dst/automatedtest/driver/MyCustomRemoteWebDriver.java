package com.dst.automatedtest.driver;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class MyCustomRemoteWebDriver extends RemoteWebDriver implements
		TakesScreenshot {

	public MyCustomRemoteWebDriver(java.net.URL url,
			DesiredCapabilities capabilities) {
		super( url , capabilities );
	}

}
