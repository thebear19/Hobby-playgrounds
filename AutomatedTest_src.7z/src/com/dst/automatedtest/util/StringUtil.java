package com.dst.automatedtest.util;

import java.util.regex.Pattern;

//import com.test.TestProperties;

public class StringUtil {
	public static final String NEW_LINE = System.getProperty("line.separator");
	
	private static Pattern SPECIAL_REGEX_CHARS = Pattern.compile("[{}()\\[\\].+*?^$\\\\|]");
	
	public static String escapeSpecialRegexChars(String str) {
	    return SPECIAL_REGEX_CHARS.matcher(str).replaceAll("\\\\$0");
	}
	
	public static String trimAtBeginofString(String s){
		return s.replaceAll("^\\s+", "");
	}
	
	public static String trimAtEndofString(String s){
		return s.replaceAll("\\s+$", "");
	}
	
	public static String trimAtBeginAndEndofString(String s){
		return StringUtil.trimAtEndofString( StringUtil.trimAtBeginofString(s) ); 
	}
	
	public static String upperBeginString(String s){
		return null;
	}
	
	public static String convertBackSlash(String str){
		str = str.replaceAll("\\\\", "\\\\\\\\");
		return str;
	}
	
	public static boolean isEmpty(String value) {
		return value == null || value.trim().length() == 0;
	}
}
