package com.dst.automatedtest.util;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;

public class CommandUtil {
	
	public static WebElement findElement(WebDriver driver,ElementBean anElement) {
		
		long startTime = Calendar.getInstance().getTimeInMillis();
		WebElement element = null;
		
		String name = anElement.getElementName() ;
		String type = selectType( anElement.getElementType().toLowerCase() );
		String value = anElement.getElementValue();
		
		// find by xpath
		if( name.indexOf("//") >= 0 || name.indexOf( "/" ) >= 0 ){
			return driver.findElement(By.xpath(anElement.getElementName()));
		}
		else{
			if(StringUtils.isBlank(name)){
				try{
					// find tag link by link text.
					return driver.findElement( By.linkText( value ) );
				}catch(NoSuchElementException ex5){
					throw ex5;
				}
			}
			// find tag link
			if( type.equalsIgnoreCase("a") ){
				try{
					// find tag link by id.
					return driver.findElement( By.cssSelector( "a[id='"+name+"']" ) );
				}catch(NoSuchElementException ex){
					try{
						// find tag link by name.
						return driver.findElement( By.cssSelector( "a[name='"+name+"']" ) );
						
					}catch(NoSuchElementException ex1){
						try{
							return driver.findElement( By.id( name ) );
						}catch(NoSuchElementException ex2){
							try{
								return driver.findElement( By.name( name ) );
							}
							catch(NoSuchElementException ex4){
								try{
									// find tag link by link text.
									return driver.findElement( By.linkText( name ) );
								}catch(NoSuchElementException ex5){
									throw ex5;
								}
							}
						}
					}
				}
			}
			else{
				try{
					return findElementByTypeandId( driver , anElement );
				}catch(NoSuchElementException ex){
					try{
						return findElementByTypeandName( driver , anElement );
					}catch(NoSuchElementException ex1){
						try{
							return findElementByTypeandValue( driver , anElement );
							//return driver.findElement(By.name(anElement.getElementName()));
						}catch(NoSuchElementException ex2){
							try{
								return driver.findElement( By.id( name ) );
							}
							catch(java.util.NoSuchElementException ex3){
								throw ex3;
							}
							/*
							try{
								//return driver.findElement(By.id(anElement.getElementName()));
							}catch(NoSuchElementException ex3){
								try{
									return findElementByTypeandValue( driver , anElement );
								}catch(NoSuchElementException ex4){
									throw ex4;
								}
							}
							*/
						}
					}
				}
			}
		}
		
		
		/*
		try {
			// find element by id 
			element = driver.findElement(By.name(anElement.getElementName()));
		} catch (NoSuchElementException ex_1) {
			try {
				// find element by name
				element = driver.findElement(By.id(anElement.getElementName()));
			} catch (NoSuchElementException ex_2) {
				try {
					// find element by xpath 			
					element = driver.findElement(By.xpath(anElement.getElementName()));
				} catch (NoSuchElementException ex_3) {
					try{
						// find element by linktext 
						element = driver.findElement(By.linkText(anElement.getElementName()));
					}catch(NoSuchElementException ex_4){
						try{
							//find element by Type and Value
							element = findElementByTypeandValue( driver , anElement );
						}catch(NoSuchElementException ex_5){
							//System.out.println( "Can't find "+anElement.getElementName() +" from driver "+ driver.getCurrentUrl() );
							throw ex_5;
						}
					}
				}
			}
		}
		*/
		
		//long endTime = Calendar.getInstance().getTimeInMillis();
		
		//System.out.println("CommandUtil.findElement :: " + (endTime - startTime) + " ms");
		//return element;
	}
	
	public static WebElement findElementByTypeandName(WebDriver driver,ElementBean anElement) throws NoSuchElementException {
		String type = selectType( anElement.getElementType().toLowerCase() );
		String name = anElement.getElementName();
			try{
				switch( type ){
				case "select" :
					return driver.findElement( By.cssSelector("select[name='"+name+"']") );
				case "image" :
					try{
						return driver.findElement( By.cssSelector("img[name='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						return driver.findElement( By.cssSelector("input[type='image'][name='"+name+"']") );
					}
				case "button" :
					try{
						return driver.findElement( By.cssSelector("button[name='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						try{
							return driver.findElement( By.cssSelector("input[type='button'][name='"+name+"']") );
						}
						catch (NoSuchElementException e1) {
							try{
								return driver.findElement( By.cssSelector("input[type='submit'][name='"+name+"']") );
							}
							catch (NoSuchElementException e2) {
								// assume that is a tab.
								return driver.findElement( By.cssSelector("li[name='"+name+"']") );
							}
						}
					}
				case "file" :
					return driver.findElement( By.cssSelector("input[type='file'][name='"+name+"']") );
				case "text" :
					try{
						return driver.findElement( By.cssSelector("input[type='text'][name='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						try{
							return driver.findElement( By.cssSelector("input[type='password'][name='"+name+"']") );
						}
						catch (NoSuchElementException e1) {
							return driver.findElement( By.cssSelector("textarea[name='"+name+"']") );
						}
					}
				default : 
					return driver.findElement( By.cssSelector("input[type='"+type+"'][name='"+name+"']") );
				}
			}
			catch(WebDriverException ex1 ){
				throw new NoSuchElementException("WebDriverException Can't find Element from "+driver.getCurrentUrl() );
			}
	}
	
	public static WebElement findElementByTypeandId(WebDriver driver,ElementBean anElement) throws NoSuchElementException {
		String type = selectType( anElement.getElementType().toLowerCase() );
		String name = anElement.getElementName();
			try{
				switch( type ){
				case "select" :
					return driver.findElement( By.cssSelector("select[id='"+name+"']") );
				case "image" :
					try{
						return driver.findElement( By.cssSelector("img[id='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						return driver.findElement( By.cssSelector("input[type='image'][id='"+name+"']") );
					}
				case "button" :
					try{
						return driver.findElement( By.cssSelector("button[id='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						try{
							return driver.findElement( By.cssSelector("input[type='button'][id='"+name+"']") );
						}
						catch (NoSuchElementException e1) {
							try{
								return driver.findElement( By.cssSelector("input[type='submit'][id='"+name+"']") );
							}
							catch (NoSuchElementException e2) {
								// assume that is a tab.
								return driver.findElement( By.cssSelector("li[id='"+name+"']") );
							}
						}
					}
				case "file" :
						return driver.findElement( By.cssSelector("input[type='file'][id='"+name+"']") );
				case "text" :
					try{
						return driver.findElement( By.cssSelector("input[type='text'][id='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						try{
							return driver.findElement( By.cssSelector("input[type='password'][id='"+name+"']") );
						}
						catch (NoSuchElementException e1) {
							return driver.findElement( By.cssSelector("textarea[id='"+name+"']") );
						}
					}
				default : 
					return driver.findElement( By.cssSelector("input[type='"+type+"'][id='"+name+"']") );
				}
			
			}
			catch(WebDriverException ex1 ){
				throw new NoSuchElementException("WebDriverException Can't find Element from "+driver.getCurrentUrl() );
			}
	}
	
	public static WebElement findElementByTypeandValue(WebDriver driver,ElementBean anElement) throws NoSuchElementException {
		long startTime = Calendar.getInstance().getTimeInMillis();
		String type = selectType( anElement.getElementType().toLowerCase() );
		String name = anElement.getElementName();
			try{
				switch( type ){
				case "select" :
					return driver.findElement( By.cssSelector("select[value='"+name+"']") );
				case "image" :
					try{
						return driver.findElement( By.cssSelector("img[value='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						return driver.findElement( By.cssSelector("input[type='image'][value='"+name+"']") );
					}
				case "button" :
					try{
						return driver.findElement( By.cssSelector("button[value='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						try{
							return driver.findElement( By.cssSelector("input[type='button'][value='"+name+"']") );
						}
						catch (NoSuchElementException e1) {
							try{
								return driver.findElement( By.cssSelector("input[type='submit'][value='"+name+"']") );
							}
							catch (NoSuchElementException e2) {
								// assume that is a tab.
								return driver.findElement( By.cssSelector("li[value='"+name+"']") );
							}
						}
					}
				case "text" :
					try{
						return driver.findElement( By.cssSelector("input[type='text'][value='"+name+"']") );
					}
					catch (NoSuchElementException e) {
						try{
							return driver.findElement( By.cssSelector("input[type='password'][value='"+name+"']") );
						}
						catch (NoSuchElementException e1) {
							return driver.findElement( By.cssSelector("textarea[id='"+name+"']") );
						}
					}
				default : 
					if("file".equals(type)){
						throw new NoSuchElementException("1. WebDriverException Can't find Element from "+driver.getCurrentUrl() );
					}
					return driver.findElement( By.cssSelector("input[type='"+type+"'][value='"+name+"']") );
				}
			}
			catch(WebDriverException ex1 ){
				throw new NoSuchElementException("2. WebDriverException Can't find Element from "+driver.getCurrentUrl() );
			}
		/*
		try{
			List<WebElement> elements = driver.findElements( By.cssSelector( "input[type='"+type+"']" ) );
			 for( WebElement element : elements ){
				 if( element.getAttribute("value").equals( anElement.getElementName() )){
					 long endTime = Calendar.getInstance().getTimeInMillis();
					 //System.out.println("CommandUtil.findElementByTypeandValue :: " + (endTime - startTime) + " ms");
					 return element;
				 }
			 }
			 long endTime = Calendar.getInstance().getTimeInMillis();
		}catch(WebDriverException ex ){
			throw new NoSuchElementException("WebDriverException Can't find Element from "+driver.getCurrentUrl() );
		}
		 //System.out.println("CommandUtil.findElementByTypeandValue :: " + (endTime - startTime) + " ms");
		 throw new NoSuchElementException("Can't Find Element "+anElement.getElementName() );
		*/
	}
	
	public static void scanElement(WebDriver driver,ElementBean anElement) throws Exception {
		String source = driver.getPageSource();
		String element = anElement.getElementName();
		System.out.println( element );
		if( source.indexOf( element ) < 0 ){
			throw new NoSuchElementException( "Element hasn't found" );
		}
		else{
			System.out.println( source.substring( source.indexOf( element )-10 , source.indexOf( element ) ) ); 
			
			int start = 0;
			for(int i=0 ; i<=source.indexOf( element ) ;i++){
				System.out.println("i "+i+"->"+ source.charAt( source.indexOf( element )-i ) );
				if(source.charAt( source.indexOf( element )-i ) == '<'){
					start = source.indexOf( element )-i;
					System.out.println("start "+ start );
					break;
				}
			}
			System.out.println( start );
			
			int end = 0;
			for(int i=0 ; i<=source.length()-source.indexOf( element ) ;i++){
				System.out.println("i "+i+"->"+ source.charAt( source.indexOf( element )+i ) );
				if(source.charAt( source.indexOf( element )+i ) == '>'){
					end = source.indexOf( element )+i;
					System.out.println("end "+ end );
					break;
				}
			}
			System.out.println( end );
			
			System.out.println( source.substring(start,end+1) );
			
			/*
			source.substring( 
					for(int i=source.indexOf( element ) ; i>=0 ;i--)
						source.charAt( source.indexOf( element )-i ).
					,
					source.indexOf( element ) ) ;
					*/
		}
	}
	
	public static void captureScreen( WebDriver driver ) {
	    try {
	    	System.out.println( "captureScreen " );
	    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile( screenshot, new File("report/main/screens/screenshots_"+( AutomatedTestEngine.Count++ )+".jpg") );
		
	    } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static boolean isXPath( String Souce ){
		boolean result = false;
		if( Souce.indexOf( "//" ) >= 0 || Souce.indexOf( "/" ) >= 0 ){
			result = true;
		}
		return result;
	}
	
	public static void switchToPopup( WebDriver driver ){
		Set<String> handles = null;
		handles = driver.getWindowHandles();
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()) {
			String subWindowHandler = iterator.next();
			if( !subWindowHandler.equals( driver.getWindowHandle() ) ){
				driver.switchTo().window(subWindowHandler);
				break;
			}
		}
	}
	
	public static void switchToMainWindow( WebDriver driver , String parentWindowHandler )throws Exception{
		Set<String> handles = null;
		long startTime = Calendar.getInstance().getTimeInMillis();
		long processTime = Calendar.getInstance().getTimeInMillis();
		long SEC20MS = 20000;
		do{
			handles = driver.getWindowHandles();
			Thread.sleep(500);
			processTime = Calendar.getInstance().getTimeInMillis();
			if( processTime - startTime >= SEC20MS ){
				throw new Exception();
			}	
		}while( handles.size() != 1 );

		if( handles.size() == 1 ){
			driver.switchTo().window(parentWindowHandler);
		}
	}
	
	/*
	private static WebElement testThread(WebDriver driver, ElementBean anElement ){
		WebElement webElement = null;
		String searchElement = anElement.getElementName();
		
		ExecutorService executor = Executors.newFixedThreadPool(10);
        List< Future<WebElement> > list = new ArrayList<Future<WebElement>>();
        FindElementCallableThread byId = new FindElementCallableThread("id",By.id( searchElement ), driver);
        FindElementCallableThread byName = new FindElementCallableThread("name",By.name( searchElement ), driver);
        FindElementCallableThread byXPath = new FindElementCallableThread("xpath",By.xpath( searchElement ), driver);
        FindElementCallableThread byLinkText = new FindElementCallableThread("LinkText",By.linkText( searchElement ), driver);
        FindElementCallableThread byPartialLinkText = new FindElementCallableThread("PartialLinkText",By.partialLinkText( searchElement ), driver);

        Future<WebElement> futurebyId = executor.submit(byId);
        Future<WebElement> futurebyName = executor.submit(byName);
        Future<WebElement> futurebyXPath = executor.submit(byXPath);
        Future<WebElement> futurebyLinkText = executor.submit(byLinkText);
        Future<WebElement> futurebyPartialLinkText = executor.submit(byPartialLinkText);

        list.add(futurebyId);
        list.add(futurebyName);
        list.add(futurebyXPath);
        list.add(futurebyLinkText);
        list.add(futurebyPartialLinkText);
        
        for(Future<WebElement> result : list){
            try {
                //print the return value of Future, notice the output delay in console
                // because Future.get() waits for task to get completed
            		System.out.println("result.get() "+ result.get() );
                	webElement = result.get();
                	//break;
            }
            catch (UnsupportedCommandException e) {
            	System.out.println( Thread.currentThread().getName() );
            }
            catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            	//result.cancel(true);
            }

        }
        //shut down the executor service now
        executor.shutdown();
        System.out.println( webElement );
        return webElement;
	}
	*/
	
	public static String selectType(String mappingType){
		String result = null;
		
		switch( mappingType ){
		case "radiobutton":
			result = "radio";
			break;
		case "checkbox":
			result = "checkbox";
			break;
		case "select":
			result = "select";
			break;
		case "button":
			result = "button";
			break;
		case "textbox":
			result = "text";
			break;
		case "image":
			result = "image";
			break;
		case "password":
			result = "password";
			break;
		case "link":
			result = "a";
			break;	
		case "upload":
			result = "file";
			break;
		default:
			result = mappingType;
			break;
		}
		
		return result;
	}
	
}
