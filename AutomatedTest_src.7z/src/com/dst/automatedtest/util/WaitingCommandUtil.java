package com.dst.automatedtest.util;

import java.util.Calendar;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dst.automatedtest.reader.ElementBean;

public class WaitingCommandUtil {
	@SuppressWarnings("unchecked")
	public static void waitForAny(WebDriver driver, String searchKey, String typeConditionClass) throws Exception {
		long startTime = Calendar.getInstance().getTimeInMillis();
		
		try{
			Class<?> c = Class.forName(typeConditionClass);
			
			ExpectedCondition<Boolean> waitCondition;
			switch (searchKey) {
			case "Ready":
				waitCondition = (ExpectedCondition<Boolean>) c.newInstance();
				break;
			default:
				waitCondition = (ExpectedCondition<Boolean>) c.getConstructor(String.class).newInstance(searchKey);
			}
		        
		    WebDriverWait wait = new WebDriverWait(driver, 12);
		    wait.until(waitCondition);
		}catch(WebDriverException e){
			long errorTime = Calendar.getInstance().getTimeInMillis();
			e.printStackTrace();
			System.out.println("Document Page Ready :: " + (errorTime - startTime) + " ms");
		}
		
	    /*long endTime = Calendar.getInstance().getTimeInMillis();
    	System.out.println("Document Page Ready :: " + (endTime - startTime) + " ms");*/
	}
	
	public static void waitForDocumentPageReady(WebDriver driver) {
		long startTime = Calendar.getInstance().getTimeInMillis();
		try{
    	// Waiting for load html page 3 sec.
    	//driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		
	    ExpectedCondition<Boolean> pageLoadCondition = new
	        ExpectedCondition<Boolean>() {
	            public Boolean apply(WebDriver driver) {
	                return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
	            }
	        };
	    WebDriverWait wait = new WebDriverWait(driver, 60);
	    wait.until(pageLoadCondition);
		}catch(WebDriverException e){
			long errorTime = Calendar.getInstance().getTimeInMillis();
			e.printStackTrace();
			System.out.println("Document Page Ready :: " + (errorTime - startTime) + " ms");
		}
	    long endTime = Calendar.getInstance().getTimeInMillis();
    	//System.out.println("Document Page Ready :: " + (endTime - startTime) + " ms");
	}
	
	public static void waitForElementEnabled(WebDriver driver,final ElementBean element){
    	long startTime = Calendar.getInstance().getTimeInMillis();
	    ExpectedCondition<Boolean> pageLoadCondition = new
	        ExpectedCondition<Boolean>() {
	            public Boolean apply(WebDriver driver) {
	                return CommandUtil.findElement(driver,element).isEnabled();
	            }
	        };
	    WebDriverWait wait = new WebDriverWait( driver, 20 );
	    wait.until(pageLoadCondition);
	    long endTime = Calendar.getInstance().getTimeInMillis();
    	//System.out.println("Document Page Ready :: " + (endTime - startTime) + " ms");
	}
	
	public static void waitForAlertUntilPresent(WebDriver driver){
		long startTime = Calendar.getInstance().getTimeInMillis();
		WebDriverWait wait = new WebDriverWait( driver, 20 );
		wait.until(ExpectedConditions.alertIsPresent());
		long endTime = Calendar.getInstance().getTimeInMillis();
		//System.out.println("waitForAlertUntilPresent :: " + (endTime - startTime) + " ms");
	}
	
	public static void waitForAjaxReturnResult(WebDriver driver,final ElementBean element) {
		long startTime = Calendar.getInstance().getTimeInMillis();
		
		WebDriverWait wait = new WebDriverWait(driver, 20 );
		
		ExpectedCondition<Boolean> pageResultCondition = new 
			ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return !"".equals( CommandUtil.findElement(driver, element).getText() );
			}
		};
		wait.until(pageResultCondition);
		
		long endTime = Calendar.getInstance().getTimeInMillis();   
		//System.out.println("waitForAlertUntilPresent :: " + (endTime - startTime) + " ms");
	}
	
	public static void waitForElementPresent(WebDriver driver,final ElementBean element) {
		long SEC30 = 30000;
		long startTime = Calendar.getInstance().getTimeInMillis();
		long processTime = 0;
		WebDriverWait wait = new WebDriverWait(driver, 30 );
		//WebElement elem = driver.findElement( By.id( element.getElementName() ) );
		
		//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); //nullify implicitlyWait() 

		//WebElement elem = wait.until( ExpectedConditions.presenceOfElementLocated( By.id( element.getElementName() ) ) );
		//driver.manage().timeouts().implicitlyWait( 12, TimeUnit.SECONDS); //reset implicitlyWait
		do{
			try{
				wait.until( ExpectedConditions.visibilityOf( CommandUtil.findElement(driver,element) ) );
				return;
			}catch(Exception ex){}
			processTime = Calendar.getInstance().getTimeInMillis();
		}while( processTime - startTime <= SEC30 );
		long endTime = Calendar.getInstance().getTimeInMillis();  
		//System.out.println("waitForElementPresent :: " + (endTime - startTime) + " ms");
	}
	
	public static void waitPresent(WebDriver driver) {
		long startTime = Calendar.getInstance().getTimeInMillis();
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		long endTime = Calendar.getInstance().getTimeInMillis();  
		//System.out.println("waitForPresent :: " + (endTime - startTime) + " ms");
	}

	public static void waitForElementEnabled(WebDriver driver, final WebElement element) {
		// TODO Auto-generated method stub
		long startTime = Calendar.getInstance().getTimeInMillis();
	    ExpectedCondition<Boolean> pageLoadCondition = new
	        ExpectedCondition<Boolean>() {
	            public Boolean apply(WebDriver driver) {
	                return element.isEnabled();
	            }
	        };
	    WebDriverWait wait = new WebDriverWait( driver, 20 );
	    wait.until(pageLoadCondition);
	    long endTime = Calendar.getInstance().getTimeInMillis();
    	//System.out.println("Document Page Ready :: " + (endTime - startTime) + " ms");
	}
	
	public static boolean waitForPopupPresent(WebDriver driver){
    	long startTime = Calendar.getInstance().getTimeInMillis();
	    ExpectedCondition<Boolean> pageLoadCondition = new
	        ExpectedCondition<Boolean>() {
	            public Boolean apply(WebDriver driver) {
	            	boolean popupIsPresentAlready = false;
	            	Set<String> handles = null;
	            	do{
						try {
							Thread.sleep( 500 );
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						handles = driver.getWindowHandles();
						popupIsPresentAlready = true;	
						
					}while( handles.size() == 1 );
	            	
	                return popupIsPresentAlready;
	            }
	        };
	    WebDriverWait wait = new WebDriverWait( driver, 20 );
	    boolean result = wait.until(pageLoadCondition);
	    long endTime = Calendar.getInstance().getTimeInMillis();
    	//System.out.println("Document Page Ready :: " + (endTime - startTime) + " ms");
	    return result;
	}

}
