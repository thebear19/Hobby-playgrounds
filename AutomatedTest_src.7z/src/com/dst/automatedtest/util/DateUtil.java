package com.dst.automatedtest.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static String getCurrentDate(){
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyy"); //08202015
    	Date date = new Date();
    	//System.out.println(dateFormat.format(date));
    	return dateFormat.format(date);
	}
	
	public static String getCurrentDate(String format){
		DateFormat dateFormat = new SimpleDateFormat( format ); //08202015
    	Date date = new Date();
    	//System.out.println(dateFormat.format(date));
    	return dateFormat.format(date);
	}
}
