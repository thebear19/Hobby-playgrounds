package com.dst.automatedtest.util;

import org.junit.Assert;

public class AssertionUtil {

	public AssertionUtil() {
		// TODO Auto-generated constructor stub
	}
	
	public static boolean AssertThat( String actual , String expect ){
	    try {
	    	Assert.assertEquals( actual , expect );
	    	return true;
	    } catch (Error e) {
	    	return false;
	    }
	}

	public static boolean isDisable( String actual , String expect ){
	    try {
	    	Assert.assertEquals( actual , expect );
	    	return true;
	    } catch (Error e) {
	    	return false;
	    }
	}
	
	public static boolean isEnable( String actual , String expect ){
	    try {
	    	Assert.assertEquals( actual , expect );
	    	return true;
	    } catch (Error e) {
	    	return false;
	    }
	}
	
	public static boolean isVisible( String actual , String expect ){
	    try {
	    	Assert.assertEquals( actual , expect );
	    	return true;
	    } catch (Error e) {
	    	return false;
	    }
	}
	
	public static boolean isInvisible( String actual , String expect ){
	    try {
	    	Assert.assertEquals( actual , expect );
	    	return true;
	    } catch (Error e) {
	    	return false;
	    }
	}
	
	public static boolean isNull( String actual , String expect ){
	    try {
	    	Assert.assertEquals( actual , expect );
	    	return true;
	    } catch (Error e) {
	    	return false;
	    }
	}
}
