package com.dst.automatedtest.util;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.poi.POIXMLDocument;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.dst.automatedtest.reader.PropertyReader;

public class FileUtil {
	
	public static boolean backupFile(String fileName) throws IOException{
		boolean result = false;
		File oldfile = new File( fileName );
		File newfile = new File( fileName +"_"+ DateUtil.getCurrentDate() );
		//newfile.mkdirs();
		if( oldfile.exists() ){
			//if( oldfile.isDirectory() ){
				result = oldfile.renameTo( newfile );
			//}
		}
		return result;
	}
	
	public static boolean backupDirectory(String fileName) throws IOException{
		boolean result = false;
		File oldfile = new File( fileName );
		File newfile = new File( fileName +"_"+ DateUtil.getCurrentDate() );
		//newfile.mkdirs();
		if( oldfile.exists() ){
			//if( oldfile.isDirectory() ){
				result = oldfile.renameTo( newfile );
			//}
		}
		return result;
	}
	
	public static boolean createTmpFile(String fileName) throws IOException{
		boolean result = false;
		File newfile = new File( fileName +"_"+ DateUtil.getCurrentDate() );
		return result;	
	}
	
	public static boolean createTmpPropertiesFile(String fileName) throws IOException{
    	File f = new File(fileName);
		return f.createNewFile();	
	}
	
	public static void appendFile(String path, String s, boolean newLine){
		BufferedWriter out = null;
		try{
			FileWriter fstream = new FileWriter(path,true);
			out = new BufferedWriter(fstream);
			if(newLine){
				out.write(StringUtil.NEW_LINE);
			}
			out.write(s);
		}catch(IOException e){
			
		}finally{
			if(out != null){
				try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	
	public static boolean isExcel(String fullPath) throws IOException{
		Boolean result = false;
		BufferedInputStream fs = null;
		
		if(fullPath.endsWith("xlsx") || fullPath.endsWith("xls")){
			try{
				fs = new BufferedInputStream(new FileInputStream(fullPath));
			
				result = (POIFSFileSystem.hasPOIFSHeader(fs) || POIXMLDocument.hasOOXMLHeader(fs));
			}finally{
				fs.close();
			}
		}
		
		return result;
	}
	
	public static String stringToFullPath(String fileName) throws IOException {
		String fullPath = PropertyReader.FUNCTION_PATH + "\\" + fileName;
		Path filePath = Paths.get(fullPath);
		
		if (!Files.exists(filePath)) {
			throw new IOException("[ERRORLOG]: File " + fileName + " not found.");
		}

		return fullPath;
	}
}
