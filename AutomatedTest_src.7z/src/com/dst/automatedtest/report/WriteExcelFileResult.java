package com.dst.automatedtest.report;

import java.io.FileInputStream;import java.io.FileNotFoundException;import java.io.FileOutputStream;import java.io.IOException;

import java.util.List;import org.apache.poi.EncryptedDocumentException;import org.apache.poi.hssf.usermodel.HSSFWorkbook;import org.apache.poi.openxml4j.exceptions.InvalidFormatException;import org.apache.poi.ss.usermodel.CreationHelper;import org.apache.poi.ss.usermodel.Row;import org.apache.poi.ss.usermodel.Sheet;import org.apache.poi.ss.usermodel.Workbook;import org.apache.poi.ss.usermodel.WorkbookFactory;

public class WriteExcelFileResult {

    public static  String currentDir = null;
	private static Workbook wb;
	private static CreationHelper createHelper;
    
    public static String getCurrentDir() {
		return currentDir;
	}
	public static  void setCurrentDir() {
		currentDir = System.getProperty("user.dir");
	}

	public static void createExcelFileResult(String path){
    	 wb = new HSSFWorkbook();
    	 FileOutputStream fileOut;
		try {
			setCreateHelper(wb.getCreationHelper());
			Sheet sheet = wb.createSheet("Automate Script Test");
			Row row = sheet.createRow((short)0);
			row.createCell(0).setCellValue("KEY");
			row.createCell(1).setCellValue("VALUE");						row.createCell(2).setCellValue("CONCATE_VALUE");
			fileOut = new FileOutputStream(path);
			wb.write(fileOut);
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }


    
    public static void appendExcelFileResult(String[] values){
    	String workingDir = System.getProperty("user.dir");
		try {
			Workbook wb = WorkbookFactory.create(new FileInputStream(workingDir+"testValue\\excelfileresult.xls"));
			Sheet sheet = wb.getSheetAt(0);
			Row row = sheet.createRow((short)sheet.getLastRowNum()+1);
			for(int i=0;i<values.length;i++){
				row.createCell(i).setCellValue(values[i]);
			}
			FileOutputStream fileOut = new FileOutputStream(workingDir+"testValue\\excelfileresult.xls");
			wb.write(fileOut);
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

   }
    public static void appendExcelFileResult(String key,String value, List<String> list){
    	String workingDir = System.getProperty("user.dir");
		try {
			System.out.println("appendExcelFileResult2");
			Workbook wb = WorkbookFactory.create(new FileInputStream(workingDir+"\\testValue\\excelfileresult.xls"));				Sheet sheet = wb.getSheetAt(0);			if( null!=list && list.size()>0){	            for(int i=0;i<list.size();i++){
				Row row = sheet.createRow((short)sheet.getLastRowNum()+1);					System.out.println("Before");					row.createCell(0).setCellValue(key);					row.createCell(1).setCellValue(value);					row.createCell(2).setCellValue(value.concat(list.get(i)));	            }			}else{				Row row = sheet.createRow((short)sheet.getLastRowNum()+1);				row.createCell(0).setCellValue(key);				row.createCell(1).setCellValue(value);			}

			FileOutputStream fileOut = new FileOutputStream(workingDir+"\\testValue\\excelfileresult.xls");
			wb.write(fileOut);
			System.out.println("After");
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

   }
	public static CreationHelper getCreateHelper() {
		return createHelper;
	}
	public static void setCreateHelper(CreationHelper createHelper) {
		WriteExcelFileResult.createHelper = createHelper;
	}

}
