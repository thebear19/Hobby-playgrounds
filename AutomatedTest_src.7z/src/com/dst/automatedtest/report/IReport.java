package com.dst.automatedtest.report;

import java.util.HashMap;
import java.util.Map;

public abstract class IReport {
	private static int TOTAL_TESTCASE = 0;
	private static int SUCCESS_CASE = 0;
	private static int FAILED_CASE = 0;
	private static int RETESTING_CASE = 0;
	public static Map<String,String> MAPPING = new HashMap< String, String >();
	
	public static int getTOTAL_TESTCASE() {
		return TOTAL_TESTCASE;
	}
	public static void setTOTAL_TESTCASE(int tOTAL_TESTCASE) {
		TOTAL_TESTCASE = tOTAL_TESTCASE;
	}
	public static int getSUCCESS_CASE() {
		return SUCCESS_CASE;
	}
	public static void setSUCCESS_CASE(int sUCCESS_CASE) {
		SUCCESS_CASE = sUCCESS_CASE;
	}
	public static int getFAILED_CASE() {
		return FAILED_CASE;
	}
	public static void setFAILED_CASE(int fAILED_CASE) {
		FAILED_CASE = fAILED_CASE;
	}
	public static int getRETESTING_CASE() {
		return RETESTING_CASE;
	}
	public static void setRETESTING_CASE(int rETESTING_CASE) {
		RETESTING_CASE = rETESTING_CASE;
	}
	public static void increaseTOTAL_TESTCASE() {
		TOTAL_TESTCASE++;
	}
	public static void increaseSUCCESS_CASE() {
		SUCCESS_CASE++;
	}
	public static void increaseFAILED_CASE() {
		FAILED_CASE++;
	}
	public static void increaseRETESTING_CASE() {
		RETESTING_CASE++;
	}
	
	public static void decreaseFAILED_CASE() {
		FAILED_CASE--;
	}
}
