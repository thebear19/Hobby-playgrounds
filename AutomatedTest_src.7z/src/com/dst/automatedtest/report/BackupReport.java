package com.dst.automatedtest.report;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import org.apache.logging.log4j.core.LoggerContext;

import com.dst.automatedtest.util.DateUtil;

public class BackupReport {
	
	public static final String DATE_FORMAT = "yyyyMMdd";
	public static final String DATE_FORMAT_FULL = "yyyyMMdd-HHmmss";
	public static final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
	public static final SimpleDateFormat sdffull = new SimpleDateFormat(DATE_FORMAT_FULL);
	
	static {
		init();
	}
	
	public static void init(){
	
		setProperties("reportName", "report");
		setProperties("main", "main");
		setProperties("screens", "screens");
		setProperties("dateTime", sdf.format( new Date() ) );
		setProperties("dateTimeFull", sdffull.format( new Date() ) );
		
		createReportDir();

	}
	
	public static void backupDirectory() {
		try{
			System.out.println("Backup report..");
			
			File reportDir = new File( "report" );
			File mainDir = new File( "report/main" );
			File tmpDir = new File( "report/"+DateUtil.getCurrentDate("yyyyMMdd") );
			
			Path mainPath = Paths.get(mainDir.toURI());
			
			String count = CountDir( "report/"+DateUtil.getCurrentDate("yyyyMMdd") );
			File tmpReportDir = new File( "report/"+DateUtil.getCurrentDate("yyyyMMdd")+"/"+count );

			reportDir.mkdirs();
			mainDir.mkdirs(); 
			
			if(mainDir.listFiles().length == 1 ){
				return;
			}

			if( count == null ){
				tmpDir.mkdirs();
				tmpReportDir = new File( "report/"+DateUtil.getCurrentDate("yyyyMMdd")+"/1");
			}
			tmpReportDir.mkdirs();
			
			Files.move( mainDir.toPath() , tmpReportDir.toPath() , StandardCopyOption.REPLACE_EXISTING );
		}
		catch( Exception ex){ /*ex.printStackTrace();*/ }
	}
	
	
	public static String CountDir(String fullPath){
		try{
			File fn = new File ( fullPath );
			String count = Integer.toString( fn.listFiles().length+1 );
			return count ;
		}
		catch( Exception ex){
			//ex.printStackTrace();
			return null;
		}
	}
	
	public static void reConfig(){
		LoggerContext ctx =(LoggerContext) LogManager.getContext(false);
		ctx.reconfigure();
	}
	
	public static void changeReportFileNm(String fileName){
		System.setProperty("reportName", fileName);
	}

	//BackupFile
	public static void createReportDir(){
		File fn = null; 
		
		fn = new File( "report" );
		fn.mkdirs();
		
		fn = new File( "report/main" );
		fn.mkdirs();
		
		fn = new File( "report/main/screens" );
		fn.mkdirs();
		 
	}

	public static void setProperties(String key , String value ){
		System.setProperty( key , value );
	}

	public static void stopLogger(){
		//stop previous logger for start new logger file.
		LoggerContext ctx =(LoggerContext) LogManager.getContext(false);
		ctx.stop();
	}
}
