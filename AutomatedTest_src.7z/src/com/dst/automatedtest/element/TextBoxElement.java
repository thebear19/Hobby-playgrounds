package com.dst.automatedtest.element;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.reader.ElementBean;

public class TextBoxElement extends WebElementImpl {

	public TextBoxElement(WebElement element) {
		super(element);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
