package com.dst.automatedtest.element;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.PropertyReader;
import com.dst.automatedtest.util.StringUtil;

public class FileUploadElement extends WebElementImpl {

	public FileUploadElement(WebElement element) {
		super(element);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	 @Override
	public void sendKeys(CharSequence... keysToSend) {
		WebDriverWait wait = new WebDriverWait( AutomatedTestEngine.getDriver(), 10 );
		String pathFile = keysToSend[0].toString();
		String functionPath = ( new java.io.File("").getAbsolutePath() ) + "\\" + (PropertyReader.FUNCTION_PATH).replace(".\\", "");
		
		if(!functionPath.endsWith("\\")){
			functionPath += "\\";
		}
		
		if (pathFile.trim().length() > 0) {
			
			if( pathFile.indexOf(".\\") >= 0 ){
				pathFile = functionPath + pathFile.replace(".\\", "") ;
			}
			/*else if( keysToSend[0].toString().indexOf("./") >= 0 ){
				pathFile = ( new java.io.File("").getAbsolutePath() ) + 
						"/"+
						pathFile.replace("./", "") ;
			}*/
			
//			pathFile = pathFile.replaceFirst(".", StringUtil.convertBackSlash(PropertyReader.FUNCTION_PATH));
			System.out.println( pathFile );
			element.sendKeys(pathFile);
		}
		else{
		wait.until(
				ExpectedConditions.textToBePresentInElementValue( 
														element, 
														keysToSend[0].toString() ) );
		}
	}
	 
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}

}
