package com.dst.automatedtest.element;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dst.automatedtest.reader.ElementBean;

public class CommandElement extends WebElementImpl {
	
	private WebDriver driver = null;
	
	public CommandElement() {		
		super(null);
		buildMethodMap();
	}
	
	public CommandElement(WebDriver driver) {		
		super(null);
		buildMethodMap();
		this.driver = driver;
	}	
		
	
	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		//methodMap.put("waitUntilPresence", this.getClass().getMethod("waitUntilPresence", ElementBean.class));
		methodMap.put("getURLTitle", this.getClass().getMethod( "getURLTitle" ));
		methodMap.put("sleep", this.getClass().getMethod( "sleep" ));
	}
    
	protected void processInvokeMethod(ElementBean element) throws Exception {

		String methodName = element.getMethod();
		Method method = getMethod(methodName);

		switch (methodName) {
		/*
		case "waitUntilPresence":
			method.invoke(this);
			break;
		*/
		case "getURLTitle":
			method.invoke(this);
			break;
		case "sleep":
			method.invoke(this);
			break;	
		}
	}

	protected void postInvokeMethod(ElementBean element) throws Exception {

	}
    
    public void getURLTitle(){
    	System.out.println( driver.getTitle() );
    	//System.out.println( driver.getCurrentUrl() );
    }
    
    public void sleep(){
    	try {
			Thread.sleep( 10000 );
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}

    
}
