package com.dst.automatedtest.element;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;

public class ImageElement extends WebElementImpl {

	public ImageElement(WebElement element) {
		super(element);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

    @Override
    public void click() {
		WebDriverWait wait = new WebDriverWait(AutomatedTestEngine.getDriver(), 10);
    	wait.until(ExpectedConditions.elementToBeClickable( element ));
    	JavascriptExecutor executor = (JavascriptExecutor) AutomatedTestEngine.getDriver();
		executor.executeScript("arguments[0].scrollIntoView(true);arguments[0].click();", element);
    }

	
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}
