package com.dst.automatedtest.element;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.dst.automatedtest.reader.ElementBean;

public class SelectElement extends WebElementImpl {
	
	
	private final Select selectElement;
	
	public SelectElement(WebElement element) {
		super(element);
		selectElement = new Select(element);
		if( selectElement.isMultiple() )
			selectElement.deselectAll();
	}
	
	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("selectByVisibleText", this.getClass().getMethod("selectByVisibleText", String.class));
		methodMap.put("selectByIndex", this.getClass().getMethod("selectByIndex", String.class));
		methodMap.put("selectByValue", this.getClass().getMethod("selectByValue", String.class));	
		methodMap.put("selectMultipleByVisibleText", this.getClass().getMethod("selectMultipleByVisibleText", String.class));
		methodMap.put("selectMultipleByIndex", this.getClass().getMethod("selectMultipleByIndex", String.class));
		methodMap.put("selectMultipleByValue", this.getClass().getMethod("selectMultipleByValue", String.class));
	}
	
	
	public void processInvokeMethod(ElementBean element) throws Exception{
		
		String elementValue = element.getElementValue();
		String methodName = element.getMethod();
		Method method = getMethod(methodName);
	
		switch ( methodName ) {
		case "selectByVisibleText":
			method.invoke(this, elementValue);
			break;
		case "selectByIndex":
			method.invoke(this, elementValue);
			break;
		case "selectByValue":
			method.invoke(this, elementValue);
			break;
		case "selectMultipleByVisibleText":
			method.invoke(this, elementValue);
			break;
		case "selectMultipleByIndex":
			method.invoke(this, elementValue);
			break;
		case "selectMultipleByValue":
			method.invoke(this, elementValue);
			break;
		}
		
	}
	
	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public void selectByVisibleText(String text) {
		//List<WebElement> ab =  selectElement.getOptions();
		//printList( ab );
		selectElement.selectByVisibleText(text);
	}
	
	
	public void printList( List<WebElement> list ){
		Iterator<WebElement> CrunchifyIterator = list.iterator();

		while (CrunchifyIterator.hasNext()) {
			System.out.println("print select "+CrunchifyIterator.next().getText());
		}
	}
	
	public void selectByIndex(String index) {
		selectElement.selectByIndex(Integer.parseInt(index));
	}
	
	public void selectByValue(String text) {
		selectElement.selectByValue(text);
	}
	
	public void selectMultipleByVisibleText(String textList) {
		
		String[] list = textList.split(",");
		
		for (String aValue : list) {
			selectElement.selectByVisibleText(aValue);
		}
		
	}
	
	public void selectMultipleByIndex(String indexList) {
		
		String[] list = indexList.split(",");
		
		for (String aValue : list) {
			selectElement.selectByIndex(Integer.parseInt(aValue));
		}
		
	}
	
	public void selectMultipleByValue(String textList) {
		
		String[] list = textList.split(",");
		
		for (String aValue : list) {
			selectElement.selectByValue(aValue);
		}
		
	}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
