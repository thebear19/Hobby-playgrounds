package com.dst.automatedtest.element;

import java.lang.reflect.Method;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.reader.ElementBean;

public class TextEditorElement extends WebElementImpl {
	
	private WebDriver driver = null;
	
	public TextEditorElement( WebElement element, WebDriver driver ) {
		super(element);
		this.driver = driver;		
	}
	
	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("setData", this.getClass().getMethod("setData", String.class));
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);

		switch (methodName) {
		case "setData":
			method.invoke(this , element.getElementValue() );
			break;
		
		}
	}
	
	public void setData(String value){
		//System.out.println("$('"+element.getAttribute("name")+"').Data = '"+value+"'; :: "+"$('"+element.getAttribute("name")+"').Data = '"+value+"';");
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript("$('"+element.getAttribute("name")+"').focus();"+"$('"+element.getAttribute("name")+"').Data = '"+value+"';");
		} 
	}

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}


	
}
