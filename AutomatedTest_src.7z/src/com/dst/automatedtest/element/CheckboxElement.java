package com.dst.automatedtest.element;

import java.lang.reflect.Method;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.util.CommandUtil;

public class CheckboxElement extends WebElementImpl {

	protected List<WebElement> elements = null;
	private WebDriver driver = null;
	
	public CheckboxElement( WebElement element, WebDriver driver ) {
		super(element);
		this.driver = driver;
		findAllCheckBoxElement( element );
	}
	
	private void findAllCheckBoxElement(WebElement element ){
		elements = driver.findElements( By.cssSelector( "input[type='checkbox'][name='"+element.getAttribute("name")+"']" ) );
	}

	public void buildMethodMapMore() throws NoSuchMethodException, SecurityException{
			methodMap.put("check", this.getClass().getMethod("check", String.class, boolean.class));
			methodMap.put("isSelect", this.getClass().getMethod("isSelect", String.class, boolean.class));
			methodMap.put("checkEnabled", this.getClass().getMethod("checkEnabled", String.class, boolean.class));
	}
	
	public void processInvokeMethod(ElementBean element) throws Exception{
		
		String elementValue = element.getElementValue();
		boolean elementIsXPath = CommandUtil.isXPath( element.getElementName() );
		String methodName = element.getMethod();
		Method method = getMethod(methodName);
	
		switch ( methodName ) {
		case "check":
			method.invoke(this, elementValue , elementIsXPath );
			break;
		case "isSelect":
			method.invoke(this, elementValue , elementIsXPath );
			break;
		case "checkEnabled":
			method.invoke(this, elementValue , elementIsXPath );
			break;
		}
		
	}
	
	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public void check( String value , boolean elementIsXPath ){
		if( elementIsXPath || elements.size() == 0 ){
			if( element.isSelected() ){
				System.out.print("unchecked checkBox ");
			}else{
				System.out.print("checked checkbox ");
			}
			System.out.println(element.getAttribute("name")+" "+value);
			element.click();
		}
		else{
			for(int i=0; i<elements.size() ; i++ )
			{
				if( elements.get( i ).getAttribute("value").equals(value) ){
					
					if( elements.get( i ).isSelected() ){
						System.out.print("unchecked checkBox ");
					}else{
						System.out.print("checked checkbox ");
					}
					System.out.println(elements.get( i ).getAttribute("name")+" "+value);
					elements.get( i ).click();
				}else if( StringUtils.isBlank(value) ){
					elements.get( i ).click();
				}
			}
		}
	}
	
	public void checkEnabled( String value , boolean elementIsXPath ){
		if( elementIsXPath || elements.size() == 0 ){
			if( element.isSelected() ){
				System.out.print("unchecked checkBox ");
			}else{
				System.out.print("checked checkbox ");
			}
			System.out.println(element.getAttribute("name")+" "+value);
			element.click();
		}
		else{
			for(int i=0; i<elements.size() ; i++ )
			{
				if( elements.get( i ).getAttribute("value").equals(value) ){
					
					if( elements.get( i ).isSelected() ){
						System.out.print("unchecked checkBox ");
					}else{
						System.out.print("checked checkbox ");
					}
					System.out.println(elements.get( i ).getAttribute("name")+" "+value);
					elements.get( i ).click();
				}else if( StringUtils.isBlank(value) ){
					System.out.println(elements.get( i ).getAttribute("name")+" "+elements.get( i ).getAttribute("id"));
					if( elements.get( i ).isDisplayed() && elements.get( i ).isEnabled() ){
						elements.get( i ).click();
					}
				}
			}
		}
	}
	
	public void isSelect( String value , boolean elementIsXPath ){
		if( elementIsXPath || elements.size() == 0 ){
			checkElementSelect( element );
		}
		else{
			for(int i=0; i<elements.size() ; i++ ){
				if( elements.get( i ).getAttribute("value").equals(value) ){
					System.out.print(elements.get( i ).getAttribute("name")+" "+value);
					checkElementSelect( elements.get( i ) );
				}
			}
		}
	}
	
	private void checkElementSelect( WebElement element ){
		if( element.isSelected() ){
			System.out.println(" checkBox is checked");
		}else{
			System.out.println(" checkBox is unchecked");
		}
	}
	
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
