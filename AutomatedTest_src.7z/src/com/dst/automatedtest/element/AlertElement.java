package com.dst.automatedtest.element;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;

import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.PropertyReader;
import com.dst.automatedtest.util.CommandUtil;
import com.dst.automatedtest.util.StringUtil;

public class AlertElement extends WebElementImpl {
	private WebDriver driver = null;
	private Alert alt = null;
	
	public AlertElement(WebDriver driver) {
		super(null);
		buildMethodMap();
		this.driver = driver;
	}
	
	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("ok", this.getClass().getMethod("ok"));
		methodMap.put("okAndWaiting", this.getClass().getMethod("okAndWaiting"));
		methodMap.put("capture", this.getClass().getMethod("capture"));
		methodMap.put("captureAndClick", this.getClass().getMethod("captureAndClick"));
		methodMap.put("captureAndCancel", this.getClass().getMethod("captureAndCancel"));
		methodMap.put("cancel", this.getClass().getMethod("cancel"));
		methodMap.put("keepValueAndClick", this.getClass().getMethod("keepValueAndClick", ElementBean.class));
		methodMap.put("keepAndCancel", this.getClass().getMethod("keepAndCancel", ElementBean.class));
	}
   
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);

		switch (methodName) {
		case "ok":
			method.invoke(this);
			break;
		case "okAndWaiting":
			method.invoke(this);
			break;
		case "capture":
			method.invoke(this);
			break;
		case "captureAndClick":
			method.invoke(this);
			break;
		case "cancel":
			method.invoke(this);
			break;
		case "keepValueAndClick":
			method.invoke(this, element);
			break;
		case "keepAndCancel":
			method.invoke(this, element);
			break;
		}
	}

	protected void postInvokeMethod(ElementBean element) throws Exception {

	}
    
    public void ok() throws Exception{
//    	System.out.println("In OK");

    	try {
    	    alt = driver.switchTo().alert();
    	    alt.accept();
    	} catch(NoAlertPresentException e) {
    		
    	}
    }
    
    public void okAndWaiting() throws Exception{
//    	System.out.println("In okAndWaiting");

    	try {
    	    alt = driver.switchTo().alert();
    	    alt.accept();
    	    Thread.sleep(5000);
    	} catch(NoAlertPresentException e) {
    		
    	}
    }
    
    public void capture() throws Exception{
    	CommandUtil.captureScreen(driver);
    }
    
    public void captureAndClick() throws Exception{
    	capture();
    	ok();
    }
    
    public void captureAndCancel() throws Exception{
    	capture();
    	cancel();
    }
    
    public void cancel() throws Exception{
    	alt = driver.switchTo().alert();
    	alt.dismiss();
    }
    
    public void keepValueAndClick(ElementBean elem) throws Exception{
//    	System.out.println("In keepValueAndClick");
    	keep(elem);
    	ok();
    }
    
    public void keepAndCancel(ElementBean elem) throws Exception {
//    	System.out.println("In keepAndCancel");
    	keep(elem);
    	cancel();
    }
    
	private void keep(ElementBean elem) throws Exception {
//    	System.out.println("In ElementBean keep");
		alt = driver.switchTo().alert();
    	String txt = alt.getText();
    	String pattern = elem.getElementValue();
    	String variable = elem.getElementName();
    	String value = "";
    	
    	if( !StringUtil.isEmpty(pattern) ){
	    	switch (pattern.split("\\[")[0]) {
			case "cut_between":
				String tmp = pattern.substring( pattern.indexOf("[")+1 , pattern.indexOf("]") );
//	    		System.out.println( tmp );
	    		int start = Integer.parseInt( tmp.split(",")[0] )-1;
	    		int stop = -1;
	    		try{
	    			stop = Integer.parseInt( tmp.split(",")[1] );
	    		}catch(ArrayIndexOutOfBoundsException ex){
	    			stop = txt.length();
	    		}
	    		value = txt.substring(start, stop);
				break;
			case "cut_word":
				tmp = pattern.substring( pattern.indexOf("[")+1 , pattern.indexOf("]") );
	    		int wordAt = Integer.parseInt( tmp )-1;
	    		String [] splitter = txt.split(" ");
	    		value = splitter[wordAt]; 
				break;
			default:
		    	Pattern r = Pattern.compile(pattern);
		        Matcher m = r.matcher(txt);
		        if(m.find()){
		        	if(m.groupCount()>1){
		        		value = m.group(1);
		        	}else{
		        		value = m.group(m.groupCount());
		        	}
		        }
				break;
			}
    	}
    	PropertyReader.VARIABLE_KEY.put(variable, value);
    	save(variable);
    }
	
	private void save(String name) throws Exception {
		FileInputStream in = new FileInputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		Properties props = new Properties();
		props.load(in);
		in.close();
		FileOutputStream out = new FileOutputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		props.setProperty(name, PropertyReader.VARIABLE_KEY.get(name));
		props.store(out, null);
		out.close();
	}
	
	
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}


