package com.dst.automatedtest.element;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.lang.reflect.Method;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;

public class ButtonElement extends WebElementImpl {

	public ButtonElement(WebElement element) {
		super(element);
		buildMethodMap();
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("pdf", this.getClass().getMethod("pdf", String.class, String.class));
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);
		String name = element.getElementName();
		String value = element.getElementValue();
		
		switch (methodName) {	
		case "pdf":
			method.invoke(this, name, value);
			break;
		}		
	}
	
	public void pdf(String name, String value) throws Exception {
//		System.out.println("Downloading pdf");
		click();
		try {
            Robot robot = new Robot();
            Thread.sleep(6000);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            Thread.sleep(2000);
            robot.keyPress(KeyEvent.VK_ESCAPE);
            robot.keyRelease(KeyEvent.VK_ESCAPE);
		} catch (AWTException e) {
            e.printStackTrace();
        }
    }
	
	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}

}
