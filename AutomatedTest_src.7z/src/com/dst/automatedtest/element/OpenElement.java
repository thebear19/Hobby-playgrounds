package com.dst.automatedtest.element;

import java.lang.reflect.Method;
import java.util.ArrayList;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.IReader;
import com.dst.automatedtest.reader.PropertyReader;
import com.dst.automatedtest.util.StringUtil;

public class OpenElement extends WebElementImpl{
	
	private WebDriver driver = null;
	private IReader reader = null;
	private AutomatedTestEngine engine = null;
	private String currentFileName = null;
	
	public OpenElement() {	
		super(null);
		buildMethodMap();
	}
	
	public OpenElement(WebDriver driver,IReader reader,AutomatedTestEngine engine,String currentFileName) {		
		super(null);
		buildMethodMap();
		this.driver = driver;
		this.reader = reader;
		this.engine = engine;
		this.currentFileName = currentFileName;
	}	
		
	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("openFileAndExecute", this.getClass().getMethod("openFileAndExecute", String.class));
		methodMap.put("sheet", this.getClass().getMethod("sheet", String.class, String.class));
		
	}
 
	protected void processInvokeMethod(ElementBean element) throws Exception {

		String methodName = element.getMethod();
		Method method = getMethod(methodName);
		String value = element.getElementValue();
		String condition = element.getElementCondition();
		
		switch (methodName) {
		case "openFileAndExecute":
			method.invoke(this,value);
			break;
		case "sheet":
			method.invoke(this, value, condition);
			break;
		}
		
	}

	protected void postInvokeMethod(ElementBean element) throws Exception {

	}

    public void openFileAndExecute(String fullPathName) throws Exception{
    	fullPathName = setFullPathName(fullPathName);
    	
    	ArrayList<ElementBean> list = reader.getElementList( fullPathName );
    	engine.execute(list,true);
    }
    
    public void sheet(String fullPathName, String sheetName) throws Exception{    	
    	fullPathName = setFullPathName(fullPathName);
    	
    	ArrayList<ElementBean> list = reader.getElementList( fullPathName, sheetName );
    	engine.execute(list,true);
    }
    
    private String setFullPathName(String fullPathName) {
    	if( fullPathName.charAt( 0 ) == '.' ){
     		fullPathName = fullPathName.replaceFirst(".", StringUtil.convertBackSlash(PropertyReader.FUNCTION_PATH));
     		
     		AutomatedTestEngine.fileName.pop();
     		AutomatedTestEngine.fileName.push( fullPathName );
     	}
    	return fullPathName;
	}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}

	/*private String getFilePathFromCurrentFile(){
    	String result = null;
    	int startPoint = 0;
    	int endPoint ;
    	if( currentFileName.indexOf("/") > -1 ){
    		endPoint = currentFileName.lastIndexOf("/");
    	}
    	else{
    		endPoint = currentFileName.lastIndexOf("\\");
    		
    		if(endPoint == -1){
    			return PropertyReader.FUNCTION_PATH;
    		}
    	}
    	result = currentFileName.substring( startPoint , endPoint );
    	return result;
    }*/

}
