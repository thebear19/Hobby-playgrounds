package com.dst.automatedtest.element;

import java.lang.reflect.Method;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;

public class ScriptElement extends WebElementImpl {

	public ScriptElement(WebElement element) {
		super(element);
	}
	
	public ScriptElement() {
		super(null);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("execute", this.getClass().getMethod("execute", String.class));
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);

		switch (methodName) {
		case "execute":
			method.invoke(this , element.getElementValue() );
			break;
		
		}
	}

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

    public void execute(String script) throws InterruptedException {
    	JavascriptExecutor executor = (JavascriptExecutor) AutomatedTestEngine.getDriver();
		executor.executeScript(script);
		Thread.sleep(2000);
    }

	
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}
