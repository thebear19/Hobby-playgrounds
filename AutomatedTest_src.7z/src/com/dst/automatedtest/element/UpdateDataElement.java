package com.dst.automatedtest.element;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.Statement;

import org.openqa.selenium.Rectangle;

import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.PropertyReader;

public class UpdateDataElement extends WebElementImpl {
	public UpdateDataElement() {
		super(null);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("updateData", this.getClass().getMethod("updateData", String.class, String.class));
		
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);
		String name = element.getElementName();
		String statement = element.getElementValue();
		switch (methodName) {
		case "updateData":
			method.invoke(this, name, statement);
			break;
		}
	}
	
    public void updateData(String name, String statement) throws Exception {
    	String[] stmArry = statement.split(";");
    	String dbName = stmArry[0];
    	String stmSQL = stmArry[1];
    	Connection conn = PropertyReader.TEST_CONN_MAP.get(dbName);
    	conn.setAutoCommit(false);
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			stmt.executeUpdate(stmSQL.replaceAll("&", "' || '&' || '"));
			conn.commit();
		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.rollback();
			}
		}
    }
    
	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}
