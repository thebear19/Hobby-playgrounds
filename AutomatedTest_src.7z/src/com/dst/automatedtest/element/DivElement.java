package com.dst.automatedtest.element;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;

public class DivElement extends WebElementImpl {

	public DivElement(WebElement element) {
		super(element);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void click() {
			WebDriverWait wait = new WebDriverWait(AutomatedTestEngine.getDriver(), 1);
		    wait.until(ExpectedConditions.elementToBeClickable( element ));
		    super.click();
	}

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}
