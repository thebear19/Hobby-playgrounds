package com.dst.automatedtest.element;

import java.lang.reflect.Method;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.reader.ElementBean;

public class WaitElement extends WebElementImpl {

	public WaitElement(WebElement element) {
		super(element);
	}
	
	public WaitElement() {
		super(null);
	}
	

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("sleep", this.getClass().getMethod("sleep", String.class));
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);

		switch (methodName) {
		case "sleep":
			method.invoke(this , element.getElementValue() );
			break;		
		}
	}
	
	public void sleep(String value) throws InterruptedException {
		Thread.sleep(Integer.parseInt(value)*1000);
    }

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}
