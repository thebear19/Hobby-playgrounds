package com.dst.automatedtest.element;

import java.lang.reflect.Method;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;

import com.dst.automatedtest.reader.ElementBean;

public class SwitchWindowElement extends WebElementImpl {
	private WebDriver driver = null;
	
	public SwitchWindowElement(WebDriver driver) {
		super(null);
		buildMethodMap();
		this.driver = driver;
	}
	
	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("newWindow", this.getClass().getMethod("newWindow"));
	}
   
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);

		switch (methodName) {
		case "newWindow":
			method.invoke(this);
			break;
		}
	}

	protected void postInvokeMethod(ElementBean element) throws Exception {

	}
    
    public void newWindow() throws Exception{
    	System.out.println("New Window");
    	
    	// Store the current window handle
    	String winHandleBefore = driver.getWindowHandle();

    	// Perform the click operation that opens new window

    	// Switch to new window opened
    	for(String winHandle : driver.getWindowHandles()){
    	    driver.switchTo().window(winHandle);
    	}

    }

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
    
	
}


