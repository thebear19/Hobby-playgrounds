package com.dst.automatedtest.element;

import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dst.automatedtest.engine.AutomatedTestEngine;
import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.PropertyReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public abstract class WebElementImpl implements WebElement {

    protected WebElement element;
    protected final HashMap<String, Method> methodMap = new HashMap<String, Method>();

    public WebElementImpl(final WebElement element) {
    	if( element != null ){
    		this.element = element;
    	}
        buildMethodMap();
    }
    
    protected void buildMethodMap() {
    	
    	try {
			methodMap.put("sendKeys", this.getClass().getMethod("sendKeys", CharSequence[].class));
			methodMap.put("click", this.getClass().getMethod("click"));
			methodMap.put("clear", this.getClass().getMethod("clear"));
			methodMap.put("keepValue", this.getClass().getMethod("keepValue", ElementBean.class));
			methodMap.put("scrollToTop", this.getClass().getMethod("scrollToTop"));
			methodMap.put("focus", this.getClass().getMethod("focus"));
			buildMethodMapMore();
		} catch (SecurityException | NoSuchMethodException e) {
			e.printStackTrace();
		}
    	
    }
    
    protected abstract void buildMethodMapMore() throws NoSuchMethodException, SecurityException;
    
    public void invokeMethod(ElementBean element) throws Exception{
    	
    	try{
    		
    		preInvokeMethod( element );
	    	processInvokeMethod( element );
	    	postInvokeMethod( element );
	    	
    	}
    	catch(IllegalArgumentException 
				| IllegalAccessException 
				| InvocationTargetException e){
    		File file = new File(".");
//			for(String fileNames : file.list()) System.out.println(fileNames);
    		e.printStackTrace();
			throw e;
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		throw e;
    	}
    }
    
    protected void preInvokeMethod(ElementBean element) throws Exception{
    	String methodName = element.getMethod();
    	Method method = getMethod( methodName );
    	
    	switch ( methodName ) {
    		case "sendKeys":
				method.invoke(this, (Object) new CharSequence[] {element.getElementValue()});
				break;
			case "click":
				method.invoke(this);
				break;
			case "clear":
				method.invoke(this);
				break;
			case "keepValue":
				method.invoke(this, element);
				break;
			case "scrollToTop":
				method.invoke(this);
				break;
			case "focus":
				method.invoke(this);
				break;
		}
    }
    
    protected abstract void processInvokeMethod(ElementBean element) throws Exception;
    
    protected abstract void postInvokeMethod(ElementBean element) throws Exception;
    
    public Method getMethod(String methodName) {
		return methodMap.get(methodName);
	}

    @Override
    public void click() {
		WebDriverWait wait = new WebDriverWait(AutomatedTestEngine.getDriver(), 10);
    	wait.until(ExpectedConditions.elementToBeClickable( element ));
    	element.click();
    }

    @Override
    public void sendKeys(CharSequence... keysToSend) {
    	element.sendKeys(keysToSend);
    	WebDriverWait wait = new WebDriverWait(AutomatedTestEngine.getDriver(), 10);
    	wait.until(ExpectedConditions.textToBePresentInElementValue( element , keysToSend[0].toString() ));
    }
    
    
    public void scrollToTop() throws Exception {
		JavascriptExecutor executor = (JavascriptExecutor) AutomatedTestEngine.getDriver();
		executor.executeScript("window.scrollTo(0, 0)", "");
		
		click();
    }
    
    public void focus() throws Exception {
    	new Actions(AutomatedTestEngine.getDriver()).moveToElement(element).perform();
		
		click();
    }
    

	@Override
	public void clear() {
		element.clear();
	}

	@Override
	public WebElement findElement(By arg0) {
		return element.findElement(arg0);
	}

	@Override
	public List<WebElement> findElements(By arg0) {
		return element.findElements(arg0);
	}

	@Override
	public String getAttribute(String arg0) {
		return element.getAttribute(arg0);
	}

	@Override
	public String getCssValue(String arg0) {
		return element.getCssValue(arg0);
	}

	@Override
	public Point getLocation() {
		return element.getLocation();
	}

	@Override
	public Dimension getSize() {
		return element.getSize();
	}

	@Override
	public String getTagName() {
		return element.getTagName();
	}

	@Override
	public String getText() {
		return element.getText();
	}

	@Override
	public boolean isDisplayed() {
		return element.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		return element.isEnabled();
	}

	@Override
	public boolean isSelected() {
		return element.isSelected();
	}

	@Override
	public void submit() {
		element.submit();
	}

	@Override
	public <X> X getScreenshotAs(OutputType<X> arg0) throws WebDriverException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void keepValue(ElementBean elem) throws Exception {
    	String variable = elem.getOriginalElementValue();
    	String value = element.getAttribute("value");
    	PropertyReader.VARIABLE_KEY.put(variable, value);
    	save(variable);
    }
	
	private void save(String name) throws Exception {
		FileInputStream in = new FileInputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		Properties props = new Properties();
		props.load(in);
		in.close();
		FileOutputStream out = new FileOutputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		props.setProperty(name, PropertyReader.VARIABLE_KEY.get(name));
		props.store(out, null);
		out.close();
	}
}
