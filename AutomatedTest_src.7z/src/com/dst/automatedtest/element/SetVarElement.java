package com.dst.automatedtest.element;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;

import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.PropertyReader;
import com.dst.automatedtest.util.StringUtil;

public class SetVarElement extends WebElementImpl {
	private static DecimalFormat df = new DecimalFormat("0.#####");
	
	public SetVarElement(WebElement element) {
		super(element);
	}
	
	public SetVarElement() {
		super(null);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("evaluateAndSetValue", this.getClass().getMethod("evaluateAndSetValue", String.class, String.class));
		methodMap.put("getDate", this.getClass().getMethod("getDate", String.class, String.class));
		methodMap.put("getText", this.getClass().getMethod("getText", String.class));
		
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);
		String name = element.getElementName();
		String statement = element.getElementValue();
		
		switch (methodName) {
		case "evaluateAndSetValue":
			method.invoke(this, name, statement);
			break;
		case "getDate":
			method.invoke(this, name, statement);
			break;
		case "getText":
			method.invoke(this, statement);
			break;
		}
	}
	
    public void evaluateAndSetValue(String name, String statement) throws Exception {
    	ScriptEngineManager mgr = new ScriptEngineManager();
	    ScriptEngine engine = mgr.getEngineByName("JavaScript");
	    String value = "";
	    try {
	    	Object obj = engine.eval(statement);
		    if (obj instanceof Double) {
		    	value = df.format(obj);
			} else {
				value = String.valueOf(obj);
			}
	    	
		} catch (ScriptException se) {
			if (statement.contains("+")) {
				statement = "\"" + statement + "\"";
				statement = statement.replaceAll("\\+", "\"+\"");
				value = (String) engine.eval(statement);
		    } else {
		    	value = statement;
		    }
		}
	    PropertyReader.VARIABLE_KEY.put(name, value);
    	save(name);
    }
	
    public void getDate(String name, String statement) throws Exception {
    	String fmtPattern = "\\((.*)\\)";
    	String datePattern = "(.*)\\+";
    	String addDaysPattern = "\\+(.\\d*)";
    	
        String fmt =  getValueByPattern(statement, fmtPattern);
        String dateStr = getValueByPattern(statement, datePattern);
    	String days = getValueByPattern(statement, addDaysPattern);
    	
    	// Get date format
    	if (StringUtil.isEmpty(fmt)) {
    		fmt = "MM/dd/yyyy";
    	}
    	SimpleDateFormat dtFmt = new SimpleDateFormat(fmt, Locale.US);
    	
    	// Get date
    	Date date = new Date();
    	if (!StringUtil.isEmpty(dateStr)) {
    		try {
				date = dtFmt.parse(dateStr);
			} catch (ParseException pe) {
				// TODO Auto-generated catch block
			}
		}
    	
    	if (!StringUtil.isEmpty(days)) {
    		Calendar cal = Calendar.getInstance(Locale.US);
        	cal.setTime(date);
    		cal.add(Calendar.DATE, Integer.parseInt(days));
        	date = cal.getTime();
		}else{
		   	Calendar cal = Calendar.getInstance(Locale.US);
		   	cal.setTime(date);
		   	cal.set(Integer.parseInt(statement.split("/")[2]), Integer.parseInt(statement.split("/")[0])-1, Integer.parseInt(statement.split("/")[1]));
	       	date = cal.getTime();
		}
    	
	    PropertyReader.VARIABLE_KEY.put(name, dtFmt.format(date));
    	save(name);
    }
            
	private String getValueByPattern(String txt, String pattern) {
		String value = "";
		Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(txt);
        if(m.find()){
        	value = m.group(m.groupCount());
        }
        return value;
	}
    
	private void save(String name) throws Exception {
		FileInputStream in = new FileInputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		Properties props = new Properties();
		props.load(in);
		in.close();
		FileOutputStream out = new FileOutputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		props.setProperty(name, PropertyReader.VARIABLE_KEY.get(name));
		props.store(out, null);
		out.close();
	}
	
	public void getText(String statement) throws Exception {
	    String text= element.getText();
	    String value = "";
		if (text.contains("\n")) {		
			text = text.replaceAll("\n", "");
		} else {
		   	value = text;
		}
		
		
		PropertyReader.VARIABLE_KEY.put(statement, value);
    	save(statement);
    }
	
	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}
