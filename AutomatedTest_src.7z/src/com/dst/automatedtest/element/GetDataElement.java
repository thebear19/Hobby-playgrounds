package com.dst.automatedtest.element;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.Properties;

import org.openqa.selenium.Rectangle;

import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.reader.PropertyReader;
import com.dst.automatedtest.util.StringUtil;

public class GetDataElement extends WebElementImpl {
	private static DecimalFormat df = new DecimalFormat("0.#####");
	
	public GetDataElement() {
		super(null);
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("getDataAndSetValue", this.getClass().getMethod("getDataAndSetValue", String.class, String.class));
		
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);
		String name = element.getElementName();
		String statement = element.getElementValue();
		switch (methodName) {
		case "getDataAndSetValue":
			method.invoke(this, name, statement);
			break;
		}
	}
	
    public void getDataAndSetValue(String name, String statement) throws Exception {
    	String[] stmArry = statement.split(";");
    	String[] nmArry = name.split(";");
    	String dbName = stmArry[0];
    	String stmSQL = stmArry[1];
    	Connection conn = PropertyReader.TEST_CONN_MAP.get(dbName);
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(stmSQL.replaceAll("&", "' || '&' || '"));
			if (rs.next()) {
				for (int i = 0; i < nmArry.length; i++) {
					Object obj = rs.getObject(i + 1);
					String value = "";
				    if (obj instanceof Double) {
				    	value = df.format(obj);
					} else {
						value = String.valueOf(obj);
					}
				    nmArry[i] = nmArry[i].replaceAll(StringUtil.NEW_LINE, "").trim();
					PropertyReader.VARIABLE_KEY.put(nmArry[i], value);
				}
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.rollback();
			}
		}
		save(nmArry);
    }
    
	private void save(String[] names) throws Exception {
		FileInputStream in = new FileInputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		Properties props = new Properties();
		props.load(in);
		in.close();
		FileOutputStream out = new FileOutputStream(PropertyReader.AUTOMATE_VARIABLE_PATH);
		for (String name : names) {
			if(PropertyReader.VARIABLE_KEY.get(name)!=null){
				props.setProperty(name, PropertyReader.VARIABLE_KEY.get(name));
			}else{
				props.setProperty(name, "null");
			}
		}
		props.store(out, null);
		out.close();
	}
    
	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {}

	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}
}
