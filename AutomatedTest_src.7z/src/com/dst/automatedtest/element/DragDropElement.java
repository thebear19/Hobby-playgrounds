package com.dst.automatedtest.element;

import java.lang.reflect.Method;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.dst.automatedtest.reader.ElementBean;
import com.dst.automatedtest.util.CommandUtil;

public class DragDropElement extends WebElementImpl {

	protected WebElement target = null;
	private WebDriver driver = null;
	
	public DragDropElement(WebElement element, WebDriver driver) {
		super(element);
		this.driver = driver;
	}

	@Override
	protected void buildMethodMapMore() throws NoSuchMethodException,
			SecurityException {
		methodMap.put("dragAndDrop", this.getClass().getMethod("dragAndDrop"));
	}

	@Override
	protected void processInvokeMethod(ElementBean element) throws Exception {
		String methodName = element.getMethod();
		Method method = getMethod(methodName);
		
		checkTargetElement(element);
		
		switch (methodName) {
		case "dragAndDrop":
			method.invoke(this);
			break;
		}
	}

	@Override
	protected void postInvokeMethod(ElementBean element) throws Exception {
		
	} 
	
	public void dragAndDrop() {
		Actions builder = new Actions(driver);
		
		Action dragAndDrop = builder.clickAndHold(this.element).moveToElement(this.target).moveByOffset(0, 10).build();
		dragAndDrop.perform();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dragAndDrop = builder.click().release(this.target).build();
		dragAndDrop.perform();
	}
	
	private void checkTargetElement(ElementBean element) {
		try{
			this.target = CommandUtil.findElement(driver, createTargetElement(element));
		} catch(NoSuchElementException e){
			throw new NoSuchElementException(e.getMessage());
		}
	}
	
	private ElementBean createTargetElement(ElementBean element) {
		ElementBean target = new ElementBean();
		target.setElementName(element.getElementValue());
		target.setElementType(element.getElementType());
		
		return target;
	}

	public Rectangle getRect() {
		return null;
	}
}
