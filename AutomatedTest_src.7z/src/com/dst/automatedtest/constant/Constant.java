package com.dst.automatedtest.constant;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class Constant {
	public final static String FIREFOX = ""; 
	public final static String IE = "IE"; 
	public final static String CHROME = ""; 
	
	public static final Marker MAIN = MarkerManager.getMarker("main"); 
	public static final Marker RETEST = MarkerManager.getMarker("RETEST"); 
	
    public final static Level LEVEL_CUSTOM_COMPLETE = Level.forName("COMPLETE", 250);
    public final static Level LEVEL_CUSTOM_START = Level.forName("START", 370);
    public static final Level LEVEL_CUSTOM_IMAGE = Level.forName("IMAGE", 275);
    
	public static final Level STATUS_COMPLETE = Level.forName("COMPLETE", 250);
	public static final Level STATUS_START = Level.forName("START", 370);
	public static final Level STATUS_IMAGE = Level.forName("IMAGE", 275);
	
	public final static String IGNORE = "ignore"; 	
}
