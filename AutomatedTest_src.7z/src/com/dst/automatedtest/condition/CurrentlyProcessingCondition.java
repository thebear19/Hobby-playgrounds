package com.dst.automatedtest.condition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;

public class CurrentlyProcessingCondition implements ExpectedCondition<Boolean> {
	private String searchKey = null;
	//private int count = 0;
	
	public CurrentlyProcessingCondition(String searchKey) {
		this.searchKey = searchKey;
		//this.count=0;
	}
	
	@Override
	public Boolean apply(WebDriver driver) {
		boolean result = ( driver.findElements(By.xpath("//*[contains(@class, '"+searchKey+"')]")).size() == 0
				|| !driver.findElement(By.xpath("//*[contains(@class, '"+searchKey+"')]")).isDisplayed() );
		
		/*if(result && count>0){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		count++;*/
		
		return result;
	}
}
