package com.dst.automatedtest.condition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;

public class InvisibleCondition implements ExpectedCondition<Boolean> {
	private String searchKey = null;
	
	public InvisibleCondition(String searchKey) {
		this.searchKey = searchKey;
	}
	
	@Override
	public Boolean apply(WebDriver driver) {
		return (driver.findElements(By.className(searchKey)).size() == 0 || 
				!driver.findElement(By.className(searchKey)).isDisplayed());
	}
}
