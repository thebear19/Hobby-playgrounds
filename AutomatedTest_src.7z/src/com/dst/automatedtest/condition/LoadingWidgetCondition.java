package com.dst.automatedtest.condition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;

public class LoadingWidgetCondition implements ExpectedCondition<Boolean> {
	private String searchKey = null;
	
	public LoadingWidgetCondition(String searchKey) {
		this.searchKey = searchKey;
	}
	
	@Override
	public Boolean apply(WebDriver driver) {
		
		return ( driver.findElements(By.xpath("//img[contains(@src,'loading.gif')]")).size() == 0 || 
				!driver.findElement(By.xpath("//img[contains(@src,'loading.gif')]")).isDisplayed() );
	}
}
