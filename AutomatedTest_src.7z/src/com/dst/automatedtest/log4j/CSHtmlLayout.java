package com.dst.automatedtest.log4j;
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache license, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the license for the specific language governing permissions and
 * limitations under the license.
	*/
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.management.ManagementFactory;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.Node;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderFactory;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.AbstractStringLayout;
import org.apache.logging.log4j.core.util.Constants;
import org.apache.logging.log4j.core.util.Transform;

import com.dst.automatedtest.constant.Constant;
import com.dst.automatedtest.report.BackupReport;
import com.dst.automatedtest.report.IReport;
import com.nrs.test.TestEngine;

/**
 * Outputs events as rows in an HTML table on an HTML page.
 * <p>
 * Appenders using this layout should have their encoding set to UTF-8 or UTF-16, otherwise events containing non ASCII
 * characters could result in corrupted log files.
 * </p>
 */
@Plugin(name = "CSHtmlLayout", 
		category = Node.CATEGORY, 
		elementType = Layout.ELEMENT_TYPE, 
		printObject = true)
public final class CSHtmlLayout extends AbstractStringLayout {

    private static final long serialVersionUID = 1L;

    private static final int BUF_SIZE = 256;

    private static final String TRACE_PREFIX = "<br />&nbsp;&nbsp;&nbsp;&nbsp;";

    private static final String REGEXP = Constants.LINE_SEPARATOR.equals("\n") ? "\n" : Constants.LINE_SEPARATOR + "|\n";

    private static final String DEFAULT_TITLE = "Log4j Log Messages";

    private static final String DEFAULT_CONTENT_TYPE = "text/html";

    public static final String DEFAULT_FONT_FAMILY = "Consolas, 'Courier New', Courier, monospace";

    private final long jvmStartTime = ManagementFactory.getRuntimeMXBean().getStartTime();

    // Print no location info by default
    private final boolean locationInfo;

    private final String title;

    private final String contentType;
    
    private static int Count = 1;
    
    //TODO moving TESTCASE information to IReport.
    private static int TESTCASE_COUNT = 1;
    
    private static int RUNNING_TESTCASE = 1;
    /*
    private static int TESTCASE_COUNT = 1;
    private static int TESTCASE_FAILED = 0;
    private static int TESTCASE_SUCCESS = 0;
    */
    private static boolean FINISH = false;
    
    /**Possible font sizes */
    public static enum FontSize {
        SMALLER("smaller"), XXSMALL("xx-small"), XSMALL("x-small"), SMALL("small"), MEDIUM("medium"), LARGE("large"),
        XLARGE("x-large"), XXLARGE("xx-large"),  LARGER("larger");

        private final String size;

        private FontSize(final String size) {
            this.size = size;
        }

        public String getFontSize() {
            return size;
        }

        public static FontSize getFontSize(final String size) {
            for (final FontSize fontSize : values()) {
                if (fontSize.size.equals(size)) {
                    return fontSize;
                }
            }
            return SMALL;
        }

        public FontSize larger() {
            return this.ordinal() < XXLARGE.ordinal() ? FontSize.values()[this.ordinal() + 1] : this;
        }
    }

    private final String font;
    private final String fontSize;
    private final String headerSize;

    private CSHtmlLayout(final boolean locationInfo, final String title, final String contentType, final Charset charset,
            final String font, final String fontSize, final String headerSize) {
        super(charset);
        this.locationInfo = locationInfo;
        this.title = title;
        this.contentType = addCharsetToContentType(contentType);
        this.font = font;
        this.fontSize = fontSize;
        this.headerSize = headerSize;
    }

    private String addCharsetToContentType(final String contentType) {
        if (contentType == null) {
            return DEFAULT_CONTENT_TYPE + "; charset=" + getCharset();
        }
        return contentType.contains("charset") ? contentType : contentType + "; charset=" + getCharset();
    }

    /**
     * Format as a String.
     *
     * @param event The Logging Event.
     * @return A String containing the LogEvent as HTML.
     */
    @Override
    public String toSerializable(final LogEvent event) {
    	
        final StringBuilder sbuf = new StringBuilder(BUF_SIZE);
        boolean _islogfromMain = false;
        
        Marker _logfrom = (event.getMarker() == null) ? null : event.getMarker();
        if( _logfrom != null ){
        	if( _logfrom.equals( Constant.MAIN ) ||  _logfrom.equals( Constant.RETEST ) ){
        		_islogfromMain = true;
        	}
        }
        
        // highlight tr color 
        // complete = green
        // error = red
        if (event.getLevel().equals( Constant.LEVEL_CUSTOM_COMPLETE )){
//        	sbuf.append(Constants.LINE_SEPARATOR).append("<tr style=\"background-color:#79c74c\">").append(Constants.LINE_SEPARATOR);
        	sbuf.append(Constants.LINE_SEPARATOR).append("<tr style=\"background-color:#b3ffb3\">").append(Constants.LINE_SEPARATOR);
        }else if (event.getLevel().equals( Level.ERROR )){
//        	sbuf.append(Constants.LINE_SEPARATOR).append("<tr style=\"background-color:#f37777\">").append(Constants.LINE_SEPARATOR);
        	sbuf.append(Constants.LINE_SEPARATOR).append("<tr style=\"background-color:#ffb3b3\">").append(Constants.LINE_SEPARATOR);
        }else if (event.getLevel().equals( Constant.LEVEL_CUSTOM_START )){
//        	sbuf.append(Constants.LINE_SEPARATOR).append("<tr style=\"background-color:#fdf316\">").append(Constants.LINE_SEPARATOR);
        	sbuf.append(Constants.LINE_SEPARATOR).append("<tr style=\"background-color:#ffffcc\">").append(Constants.LINE_SEPARATOR);        	
        }
        
        /*
        Marker _logfrom = (event.getMarker() == null) ? null : event.getMarker();
        if( _logfrom != null ){
	        if( _logfrom.equals( HTMLReport.MAIN ) ||  _logfrom.equals( HTMLReport.RETEST ) ){
	        	_islogfromMain = true;
	        	if( event.getLevel().equals( HTMLReport.LEVEL_CUSTOM_COMPLETE ) ){
	        		IReport.increaseSUCCESS_CASE();
	        		//TESTCASE_SUCCESS++;
	        	}
	        	if( event.getLevel().equals( Level.ERROR ) ){
	        		if( !_logfrom.equals( HTMLReport.RETEST ) ){
	        			IReport.increaseFAILED_CASE();
	        			//TESTCASE_FAILED++;
	        		}
	        	}
	        }
        }
        */
        
        sbuf.append("<td title=\"Line\">");
        if( _islogfromMain ){
        	sbuf.append( TESTCASE_COUNT );
        }
        else{
        	sbuf.append( Count++ );
        }
        sbuf.append("</td>").append(Constants.LINE_SEPARATOR);

        //double timeSec = TimeUnit.MILLISECONDS.toSeconds(event.getTimeMillis() - jvmStartTime);
//        double timeSec = TimeUnit.MILLISECONDS.toSeconds(event.getTimeMillis() - jvmStartTime);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        sbuf.append("<td title=\"Time\" style=\"text-align: right;\">");
//        sbuf.append(timeSec + " s");
        sbuf.append(sdf.format( new Date() ));
        sbuf.append("</td>").append(Constants.LINE_SEPARATOR);

        sbuf.append("<td title=\"Level\">");
		sbuf.append(Transform.escapeHtmlTags(String.valueOf(event.getLevel())));
        sbuf.append("</td>").append(Constants.LINE_SEPARATOR);

        sbuf.append("<td title=\"Message\">");
        StringBuilder tmp = new StringBuilder();
        if( _islogfromMain && ! event.getLevel().equals( Level.INFO ) ){
        	tmp.append( "<a href='./TestCase"+(RUNNING_TESTCASE)+".html'>"+ Transform.escapeHtmlTags(event.getMessage().getFormattedMessage()).replaceAll(REGEXP, "<br />") +"</a>" );
        }
        else if( event.getLevel().equals( Constant.LEVEL_CUSTOM_IMAGE ) ){
        	tmp.append( event.getMessage().getFormattedMessage().replaceAll(REGEXP, "<br />") );
        }else{
        	tmp.append( Transform.escapeHtmlTags( event.getMessage().getFormattedMessage().replaceAll(REGEXP, "<br />") ) );
        }
        
        sbuf.append(tmp);
        sbuf.append("</td>").append(Constants.LINE_SEPARATOR);
        
        sbuf.append("</tr>").append(Constants.LINE_SEPARATOR);

        if (event.getContextStack() != null && !event.getContextStack().isEmpty()) {
            sbuf.append("<tr><td bgcolor=\"#EEEEEE\" style=\"font-size : ").append(fontSize);
            sbuf.append(";\" colspan=\"6\" ");
            sbuf.append("title=\"Nested Diagnostic Context\">");
            sbuf.append("NDC: ").append(Transform.escapeHtmlTags(event.getContextStack().toString()));
            sbuf.append("</td></tr>").append(Constants.LINE_SEPARATOR);
        }

        
        if (event.getContextMap() != null && !event.getContextMap().isEmpty()) {
            sbuf.append("<tr><td bgcolor=\"#EEEEEE\" style=\"font-size : ").append(fontSize);
            sbuf.append(";\" colspan=\"6\" ");
            sbuf.append("title=\"Mapped Diagnostic Context\">");
            sbuf.append("MDC: ").append(Transform.escapeHtmlTags(event.getContextMap().toString()));
            sbuf.append("</td></tr>").append(Constants.LINE_SEPARATOR);
        }

        final Throwable throwable = event.getThrown();
        if (throwable != null) {
            sbuf.append("<tr><td bgcolor=\"#993300\" style=\"color:White; font-size : ").append(fontSize);
            sbuf.append(";\" colspan=\"6\">");
            appendThrowableAsHtml(throwable, sbuf);
            sbuf.append("</td></tr>").append(Constants.LINE_SEPARATOR);
        }
        
  
        return sbuf.toString();
    }

    @Override
    /**
     * @return The content type.
     */
    public String getContentType() {
        return contentType;
    }

    private void appendThrowableAsHtml(final Throwable throwable, final StringBuilder sbuf) {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        try {
            throwable.printStackTrace(pw);
        } catch (final RuntimeException ex) {
            // Ignore the exception.
        }
        pw.flush();
        final LineNumberReader reader = new LineNumberReader(new StringReader(sw.toString()));
        final ArrayList<String> lines = new ArrayList<String>();
        try {
          String line = reader.readLine();
          while (line != null) {
            lines.add(line);
            line = reader.readLine();
          }
        } catch (final IOException ex) {
            if (ex instanceof InterruptedIOException) {
                Thread.currentThread().interrupt();
            }
            lines.add(ex.toString());
        }
        boolean first = true;
        for (final String line : lines) {
            if (!first) {
                sbuf.append(TRACE_PREFIX);
            } else {
                first = false;
            }
            sbuf.append(Transform.escapeHtmlTags(line));
            sbuf.append(Constants.LINE_SEPARATOR);
        }
    }

    /**
     * Returns appropriate HTML headers.
     * @return The header as a byte array.
     */
    @Override
    public byte[] getHeader() {
        final StringBuilder sbuf = new StringBuilder();
        sbuf.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" ");
        sbuf.append("\"http://www.w3.org/TR/html4/loose.dtd\">");
        sbuf.append(Constants.LINE_SEPARATOR);
        sbuf.append("<html>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<head>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<meta charset=\"").append(getCharset()).append("\"/>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<title>").append(title).append("</title>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<style type=\"text/css\">").append(Constants.LINE_SEPARATOR);
        sbuf.append("<!--").append(Constants.LINE_SEPARATOR);
        sbuf.append("body, table {font-family:").append(font).append("; font-size: ");
        sbuf.append(headerSize).append(";}").append(Constants.LINE_SEPARATOR);
        sbuf.append("th {background: #336699; color: #FFFFFF; text-align: left;}").append(Constants.LINE_SEPARATOR);
        sbuf.append("-->").append(Constants.LINE_SEPARATOR);
        sbuf.append("</style>").append(Constants.LINE_SEPARATOR);
        sbuf.append("</head>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<body topmargin=\"6\" leftmargin=\"6\" style=\"background:url(../spoon.jpg) no-repeat fixed;background-position: left bottom; width:1100px;margin-left: auto;margin-right: auto;\">").append(Constants.LINE_SEPARATOR);
        sbuf.append("<div style=\"background-color:#ffffff;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding-top: 20px;padding-bottom: 20px;padding-left: 50px; padding-right: 50px;\">").append(Constants.LINE_SEPARATOR);
        sbuf.append("<hr size=\"1\" noshade=\"noshade\">").append(Constants.LINE_SEPARATOR);
        sbuf.append("<div style='position: relative;'>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<img border='0' src='../Red velvet.jpg' width='289' height='123'>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<span style='float:right;font-size:xx-large;letter-spacing: 4px; margin-left:10px;' ><b>Automated Test Results</b></span> </div>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<hr size=\"1\" noshade=\"noshade\">").append(Constants.LINE_SEPARATOR);
        sbuf.append("<div style='text-align: right;'> Log session start time " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "</div><br>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<br>").append(Constants.LINE_SEPARATOR);
        String testCase = "<span id='testCase'>"+IReport.getTOTAL_TESTCASE()+"</span>";
        //sbuf.append("Total TestCase is : "+ TestEngine.testCaseSize ).append(Constants.LINE_SEPARATOR);
        sbuf.append("<div style='text-align: left;'> Total test cases : "+ testCase + "</div>").append(Constants.LINE_SEPARATOR);        
        
        
        
        sbuf.append(
            "<table cellspacing=\"0\" cellpadding=\"4\" border=\"1\" bordercolor=\"#224466\" width=\"100%\">");
        sbuf.append( getTHead() );
        return sbuf.toString().getBytes(getCharset());
    }

    /**
     * Returns the appropriate HTML footers.
     * @return the footer as a byte array.
     */
    @Override
    public byte[] getFooter() {
        final StringBuilder sbuf = new StringBuilder();
        sbuf.append( getTFoot() );
        sbuf.append("</table>").append(Constants.LINE_SEPARATOR);
        sbuf.append("<br><br>").append(Constants.LINE_SEPARATOR);        
        sbuf.append("<button onclick=\"window.history.back();\" style=\"background-color: #e7e7e7; color: black; border: none; padding: 10px 32px; text-align: center; text-decoration: none; display: inline-block; font-size: 14px;\">Back</button>");
        sbuf.append("<div style=\"float:right;color:#bfbfbf\"><strong>Developed By NRS</strong></div>").append(Constants.LINE_SEPARATOR);        
        sbuf.append("</div></body></html>");
        return getBytes(sbuf.toString());
    }
    
    private String getTHead(){
    	StringBuilder sbuf = new StringBuilder();
    	sbuf.append(Constants.LINE_SEPARATOR);
        sbuf.append("<thead>");
        sbuf.append("<tr>");
        sbuf.append("<th>   </th>");
        sbuf.append("<th>Timestamps</th>");
        sbuf.append("<th>Level</th>");
        if (locationInfo) {
            sbuf.append("<th>File:Line</th>");
        }
        sbuf.append("<th>Message</th>");
        sbuf.append("</tr>");
        sbuf.append(Constants.LINE_SEPARATOR);
        sbuf.append("</thead>");
        sbuf.append(Constants.LINE_SEPARATOR);
        return sbuf.toString();
    }
    
    private String getTFoot(){
    	
    	StringBuilder sbuf = new StringBuilder();
    	sbuf.append(Constants.LINE_SEPARATOR);
    	sbuf.append( "<tfoot>" );
    	sbuf.append( "<tr>" );
    	sbuf.append( "<td colspan=4>" );
    	if( isFINISH() ){
    		//sbuf.append( "Total Completed Test Case : "+ TESTCASE_SUCCESS );
    		sbuf.append( "Total test cases : "+ IReport.getTOTAL_TESTCASE() );
    		sbuf.append( "<br>" );
    		sbuf.append( "Total completed test cases : "+ IReport.getSUCCESS_CASE() );
    		sbuf.append( "<br>" );
    		//sbuf.append( "Total Failed Test cases : "+ TESTCASE_FAILED );
    		sbuf.append( "Total failed test cases : "+ IReport.getFAILED_CASE() );
    		sbuf.append( "<br>" );
    		sbuf.append( "Total retest cases : "+ IReport.getRETESTING_CASE() );
    		sbuf.append( "<br>" );
    		//sbuf.append( "Total :: "+ ( (TESTCASE_SUCCESS)*100/(TESTCASE_COUNT-1) ) +" %" );
    		sbuf.append( "Total :: "+ ( (IReport.getSUCCESS_CASE() / (IReport.getSUCCESS_CASE() + IReport.getFAILED_CASE())) * 100 ) +" %" );
    	}
    	else{
    		sbuf.append( "Finished Test cases..." );
    	}
    	sbuf.append( "</td>" );
    	sbuf.append( "</tr>" );
    	sbuf.append( "<tr>" );
    	sbuf.append( "<td colspan=4>" );
    	

    	long times =  ManagementFactory.getRuntimeMXBean().getUptime();


    	long mHOUR = TimeUnit.MILLISECONDS.toHours(times);
    	long mMINUTE = TimeUnit.MILLISECONDS.toMinutes(times) % 60;
    	long mSECOND = TimeUnit.MILLISECONDS.toSeconds(times) % 60;
    	
    	sbuf.append( "Total time : "+mHOUR+" hrs : "+mMINUTE+" mins : "+mSECOND+" secs" );
    	sbuf.append( "</td>" );
    	sbuf.append( "</tr>" );
    	sbuf.append(Constants.LINE_SEPARATOR );
    	sbuf.append( "</tfoot>" );
    	sbuf.append(Constants.LINE_SEPARATOR );
    	return sbuf.toString();
    }

    private String getJSContent(){
    	StringBuilder sbuf = new StringBuilder();
    	sbuf.append("<javascript>");
    	sbuf.append("</javascript>");
    	return sbuf.toString();
    }
    /**
     * Create an HTML Layout.
     * @param locationInfo If "true", location information will be included. The default is false.
     * @param title The title to include in the file header. If none is specified the default title will be used.
     * @param contentType The content type. Defaults to "text/html".
     * @param charset The character set to use. If not specified, the default will be used.
     * @param fontSize The font size of the text.
     * @param font The font to use for the text.
     * @return An HTML Layout.
     */
    @PluginFactory
    public static CSHtmlLayout createLayout(
            @PluginAttribute(value = "locationInfo", defaultBoolean = false) final boolean locationInfo,
            @PluginAttribute(value = "title", defaultString = DEFAULT_TITLE) final String title,
            @PluginAttribute("contentType") String contentType,
            @PluginAttribute(value = "charset", defaultString = "UTF-8") final Charset charset,
            @PluginAttribute("fontSize") String fontSize,
            @PluginAttribute(value = "fontName", defaultString = DEFAULT_FONT_FAMILY) final String font) {
        final FontSize fs = FontSize.getFontSize(fontSize);
        fontSize = fs.getFontSize();
        final String headerSize = fs.larger().getFontSize();
        if (contentType == null) {
            contentType = DEFAULT_CONTENT_TYPE + "; charset=" + charset;
        }
        return new CSHtmlLayout(locationInfo, title, contentType, charset, font, fontSize, headerSize);
    }

    /**
     * Creates an HTML Layout using the default settings.
     *
     * @return an HTML Layout.
     */
    public static CSHtmlLayout createDefaultLayout() {
        return newBuilder().build();
    }

    @PluginBuilderFactory
    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder implements org.apache.logging.log4j.core.util.Builder<CSHtmlLayout> {

        @PluginBuilderAttribute
        private boolean locationInfo = false;

        @PluginBuilderAttribute
        private String title = DEFAULT_TITLE;

        @PluginBuilderAttribute
        private String contentType = null; // defer default value in order to use specified charset

        @PluginBuilderAttribute
        private Charset charset = Constants.UTF_8;

        @PluginBuilderAttribute
        private FontSize fontSize = FontSize.SMALL;

        @PluginBuilderAttribute
        private String fontName = DEFAULT_FONT_FAMILY;

        private Builder() {
        }

        public Builder withLocationInfo(final boolean locationInfo) {
            this.locationInfo = locationInfo;
            return this;
        }

        public Builder withTitle(final String title) {
            this.title = title;
            return this;
        }

        public Builder withContentType(final String contentType) {
            this.contentType = contentType;
            return this;
        }

        public Builder withCharset(final Charset charset) {
            this.charset = charset;
            return this;
        }

        public Builder withFontSize(final FontSize fontSize) {
            this.fontSize = fontSize;
            return this;
        }

        public Builder withFontName(final String fontName) {
            this.fontName = fontName;
            return this;
        }

        @Override
        public CSHtmlLayout build() {
            // TODO: extract charset from content-type
            if (contentType == null) {
                contentType = DEFAULT_CONTENT_TYPE + "; charset=" + charset;
            }
            return new CSHtmlLayout(locationInfo, title, contentType, charset, fontName, fontSize.getFontSize(),
                fontSize.larger().getFontSize());
        }
    }

	public static int getTESTCASE_COUNT() {
		return TESTCASE_COUNT;
	}
	public static void increaseTESTCASE_COUNT() {
		TESTCASE_COUNT++;
	}
	public static void resetTESTCASE_COUNT() {
		TESTCASE_COUNT=1;
	}
	
	
	public static int getRUNNING_TESTCASE() {
		return RUNNING_TESTCASE;
	}
	public static void increaseRUNNING_TESTCASE() {
		RUNNING_TESTCASE++;
	}
	public static void resetRUNNING_TESTCASE() {
		RUNNING_TESTCASE=1;
	}
	
	
	public static boolean isFINISH() {
		return FINISH;
	}
	public static void setFINISH(boolean fINISH) {
		FINISH = fINISH;
	}

	public static int getCount() {
		return Count;
	}

	public static void setCount(int count) {
		Count = count;
	}
    
	
    
}